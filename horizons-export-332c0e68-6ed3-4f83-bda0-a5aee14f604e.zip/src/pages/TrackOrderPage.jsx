import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { MapPin, ShoppingBag, User, Clock } from "lucide-react";

// Fix for default marker icon issue with webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

const TrackOrderPage = () => {
  const [orderStatus, setOrderStatus] = useState("Preparando");
  const [estimatedTime, setEstimatedTime] = useState(25); // minutes
  const [deliveryPerson, setDeliveryPerson] = useState({
    name: "Carlos R.",
    rating: 4.8,
    vehicle: "Moto XYZ 123",
    position: { lat: 4.62, lng: -74.07 } // Initial position (example)
  });
  const restaurantPosition = { lat: 4.6027, lng: -74.0655 }; // Example restaurant
  const userPosition = { lat: 4.6389, lng: -74.0839 }; // Example user
  const mapRef = useRef(null);

  // Simulate order progress and delivery person movement
  useEffect(() => {
    const statusUpdates = ["En camino", "Cerca de tu ubicación", "Entregado"];
    let currentStatusIndex = 0;

    const interval = setInterval(() => {
      setEstimatedTime(prev => Math.max(0, prev - 5));
      
      if (currentStatusIndex < statusUpdates.length && estimatedTime <= (20 - currentStatusIndex * 10) ) {
        setOrderStatus(statusUpdates[currentStatusIndex]);
        currentStatusIndex++;
      }

      // Simulate delivery person moving
      setDeliveryPerson(prev => ({
        ...prev,
        position: {
          lat: prev.position.lat + (userPosition.lat - prev.position.lat) * 0.2, // Move 20% closer each step
          lng: prev.position.lng + (userPosition.lng - prev.position.lng) * 0.2
        }
      }));
      
      if (estimatedTime <= 0 || orderStatus === "Entregado") {
        setOrderStatus("Entregado");
        setEstimatedTime(0);
        clearInterval(interval);
      }
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, [estimatedTime, orderStatus, userPosition.lat, userPosition.lng]);
  
  useEffect(() => {
    if (mapRef.current) {
      mapRef.current.flyTo([deliveryPerson.position.lat, deliveryPerson.position.lng], mapRef.current.getZoom());
    }
  }, [deliveryPerson.position]);

  const deliveryPath = [
    [restaurantPosition.lat, restaurantPosition.lng],
    [deliveryPerson.position.lat, deliveryPerson.position.lng],
    [userPosition.lat, userPosition.lng]
  ];
  
  const bounds = L.latLngBounds(
    [restaurantPosition.lat, restaurantPosition.lng],
    [userPosition.lat, userPosition.lng]
  ).pad(0.2); // Add some padding

  return (
    <div className="container mx-auto px-4 py-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">Seguimiento de tu Pedido</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="font-medium">Estado del Pedido:</span>
              <span className="text-primary font-semibold">{orderStatus}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">Tiempo Estimado de Entrega:</span>
              <span className="text-primary font-semibold">{estimatedTime} minutos</span>
            </div>
            <Separator />
            <div className="space-y-2">
              <h3 className="font-medium text-lg">Información del Repartidor</h3>
              <div className="flex items-center gap-2">
                <User size={16} className="text-muted-foreground" /> {deliveryPerson.name}
              </div>
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-muted-foreground" /> Calificación: {deliveryPerson.rating} ★
              </div>
              <div className="flex items-center gap-2">
                <ShoppingBag size={16} className="text-muted-foreground" /> Vehículo: {deliveryPerson.vehicle}
              </div>
            </div>
            {orderStatus === "Entregado" && (
                <Button className="w-full mt-4" onClick={() => alert("¡Gracias por tu pedido!")}>
                    Confirmar Entrega y Calificar
                </Button>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            <div className="h-[400px] md:h-[500px] rounded-lg overflow-hidden">
              <MapContainer 
                center={[ (restaurantPosition.lat + userPosition.lat) / 2, (restaurantPosition.lng + userPosition.lng) / 2]} 
                zoom={13} 
                style={{ height: "100%", width: "100%" }}
                whenCreated={mapInstance => { mapRef.current = mapInstance; }}
                bounds={bounds}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                <Marker position={[restaurantPosition.lat, restaurantPosition.lng]}>
                  <Popup>Restaurante</Popup>
                </Marker>
                <Marker position={[userPosition.lat, userPosition.lng]}>
                  <Popup>Tu Ubicación</Popup>
                </Marker>
                <Marker position={[deliveryPerson.position.lat, deliveryPerson.position.lng]} 
                  icon={L.icon({iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png', iconSize: [25,41], iconAnchor:[12,41]})}>
                  <Popup>Repartidor</Popup>
                </Marker>
                <Polyline positions={deliveryPath} color="blue" />
              </MapContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default TrackOrderPage;