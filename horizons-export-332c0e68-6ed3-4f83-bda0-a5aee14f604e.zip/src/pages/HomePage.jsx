import React from "react";
import HeroSection from "@/components/home/HeroSection";
import FeaturesSection from "@/components/home/FeaturesSection";
import PopularItemsSection from "@/components/home/PopularItemsSection";
import RestaurantsSection from "@/components/home/RestaurantsSection";
import CtaSection from "@/components/home/CtaSection";
import PageLayout from "@/components/layouts/PageLayout";


const HomePage = () => {
  return (
    <PageLayout>
      <HeroSection />
      <FeaturesSection />
      <PopularItemsSection />
      <RestaurantsSection />
      <CtaSection />
    </PageLayout>
  );
};

export default HomePage;