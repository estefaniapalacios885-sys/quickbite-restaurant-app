import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { User, Mail, Phone, MapPin, LogOut, Save, Edit3 } from "lucide-react";

const ProfilePage = () => {
  const { toast } = useToast();
  const { currentUser, updateUser, logout } = useAuth();
  const navigate = useNavigate();

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    avatarUrl: ""
  });

  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || "",
        email: currentUser.email || "",
        phone: currentUser.phone || "",
        address: currentUser.address || "",
        avatarUrl: currentUser.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dXNlciUyMHByb2ZpbGV8ZW58MHx8MHx8fDA%3D&w=1000&q=80",
      });
    }
  }, [currentUser]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({ ...prev, avatarUrl: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveChanges = () => {
    updateUser(formData);
    toast({
      title: "Perfil Actualizado",
      description: "Tus cambios han sido guardados exitosamente.",
    });
    setIsEditing(false);
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Sesión Cerrada",
      description: "Has cerrado sesión exitosamente.",
    });
    navigate("/");
  };

  if (!currentUser) {
    return <p className="text-center py-10">Cargando perfil...</p>;
  }

  const getInitials = (name) => {
    if (!name) return "QU";
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-12"
    >
      <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-2xl">
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-4">
            <Avatar className="w-32 h-32 border-4 border-primary shadow-lg">
              <AvatarImage src={formData.avatarUrl} alt={currentUser.name} />
              <AvatarFallback className="text-4xl bg-gradient-to-br from-primary to-orange-400 text-white">
                {getInitials(formData.name)}
              </AvatarFallback>
            </Avatar>
            {isEditing && (
              <label htmlFor="avatarUpload" className="absolute bottom-0 right-0 bg-primary text-white p-2 rounded-full cursor-pointer hover:bg-primary/90 transition-colors">
                <Edit3 size={18} />
                <input id="avatarUpload" type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
              </label>
            )}
          </div>
          <h1 className="text-3xl font-bold text-gray-800">{formData.name}</h1>
          <p className="text-md text-muted-foreground">{formData.email}</p>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="name" className="flex items-center text-sm font-medium text-gray-700 mb-1">
                <User size={16} className="mr-2 text-primary" /> Nombre Completo
              </Label>
              <Input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleInputChange}
                disabled={!isEditing}
                className="mt-1 block w-full"
                placeholder="Tu nombre completo"
              />
            </div>
            <div>
              <Label htmlFor="email" className="flex items-center text-sm font-medium text-gray-700 mb-1">
                <Mail size={16} className="mr-2 text-primary" /> Correo Electrónico
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                disabled 
                className="mt-1 block w-full bg-gray-100 cursor-not-allowed"
                placeholder="tu@correo.com"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="phone" className="flex items-center text-sm font-medium text-gray-700 mb-1">
              <Phone size={16} className="mr-2 text-primary" /> Teléfono
            </Label>
            <Input
              id="phone"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleInputChange}
              disabled={!isEditing}
              className="mt-1 block w-full"
              placeholder="+57 300 123 4567"
            />
          </div>

          <div>
            <Label htmlFor="address" className="flex items-center text-sm font-medium text-gray-700 mb-1">
              <MapPin size={16} className="mr-2 text-primary" /> Dirección de Envío
            </Label>
            <Input
              id="address"
              name="address"
              type="text"
              value={formData.address}
              onChange={handleInputChange}
              disabled={!isEditing}
              className="mt-1 block w-full"
              placeholder="Carrera 10 #20-30, Apartamento 101"
            />
          </div>

          <div className="flex flex-col sm:flex-row justify-between items-center pt-6 gap-4">
            {isEditing ? (
              <Button onClick={handleSaveChanges} className="w-full sm:w-auto bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-500/90 hover:to-emerald-600/90 text-white">
                <Save size={18} className="mr-2" /> Guardar Cambios
              </Button>
            ) : (
              <Button onClick={() => setIsEditing(true)} className="w-full sm:w-auto">
                <Edit3 size={18} className="mr-2" /> Editar Perfil
              </Button>
            )}
            <Button variant="outline" onClick={handleLogout} className="w-full sm:w-auto border-destructive text-destructive hover:bg-destructive/10 hover:text-destructive">
              <LogOut size={18} className="mr-2" /> Cerrar Sesión
            </Button>
          </div>
          {isEditing && (
             <Button variant="ghost" onClick={() => setIsEditing(false)} className="w-full sm:w-auto mt-2 sm:mt-0">
                Cancelar
            </Button>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default ProfilePage;