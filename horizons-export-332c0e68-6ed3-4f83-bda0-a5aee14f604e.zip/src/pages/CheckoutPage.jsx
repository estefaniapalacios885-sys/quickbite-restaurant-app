import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import OrderSuccess from "@/components/OrderSuccess";
import CheckoutForm from "@/components/CheckoutForm";
import { formatCurrency } from "@/utils/formatCurrency";
import { useAuth } from "@/contexts/AuthContext";

const CheckoutPage = ({ cartItems, total, onCompleteOrder, onCancel }) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [orderSuccessful, setOrderSuccessful] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    phone: "",
    paymentMethod: "creditCard",
  });

  useEffect(() => {
    if (currentUser) {
      setFormData(prev => ({
        ...prev,
        name: currentUser.name || "",
        address: currentUser.address || "",
        phone: currentUser.phone || "",
      }));
    }
  }, [currentUser]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmitOrder = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.address || !formData.phone) {
      toast({
        title: "Campos incompletos",
        description: "Por favor, completa todos los campos de envío.",
        variant: "destructive",
      });
      return;
    }

    console.log("Order submitted:", { ...formData, cartItems, total });
    
    onCompleteOrder();
    setOrderSuccessful(true);
    
    toast({
      title: "¡Pedido Realizado!",
      description: "Gracias por tu compra. Tu pedido está en camino.",
    });
  };

  if (orderSuccessful) {
    return <OrderSuccess onContinueShopping={() => navigate("/menu")} />;
  }

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = subtotal > 0 ? 5000 : 0;
  const finalTotal = subtotal + deliveryFee;


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-8"
    >
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Finalizar Compra</h1>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Resumen del Pedido</h2>
            <ScrollArea className="h-60 pr-3">
              {cartItems.map((item) => (
                <div key={item.id} className="flex justify-between items-center py-2 border-b last:border-b-0">
                  <div>
                    <p className="font-medium">{item.name} <span className="text-xs text-muted-foreground">x{item.quantity}</span></p>
                    <p className="text-sm text-muted-foreground">{formatCurrency(item.price)} c/u</p>
                  </div>
                  <p className="font-medium">{formatCurrency(item.price * item.quantity)}</p>
                </div>
              ))}
            </ScrollArea>
            <Separator className="my-4" />
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Envío</span>
                <span>{formatCurrency(deliveryFee)}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>{formatCurrency(finalTotal)}</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <CheckoutForm 
              formData={formData}
              handleInputChange={handleInputChange}
              handleSubmitOrder={handleSubmitOrder}
              onCancel={onCancel}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default CheckoutPage;