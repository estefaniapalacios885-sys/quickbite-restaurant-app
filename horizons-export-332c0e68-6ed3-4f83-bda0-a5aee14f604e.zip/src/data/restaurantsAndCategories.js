
export const restaurants = [
  { id: "el_cielo", name: "El Cielo", logo_description: "Logo del restaurante El Cielo con diseño elegante" },
  { id: "andres_carne_de_res", name: "Andrés Carne de Res", logo_description: "Logo colorido y festivo de Andrés Carne de Res" },
  { id: "harry_sasson", name: "Harry Sasson", logo_description: "Logo sofisticado del restaurante Harry Sasson" },
  { id: "criterion", name: "Criterión", logo_description: "Logo clásico del restaurante Criterión" },
  { id: "la_provincia", name: "La Provincia", logo_description: "Logo del restaurante La Provincia con toque regional" },
  { id: "el_chato", name: "El Chato", logo_description: "Logo moderno del restaurante El Chato" },
  { id: "leo", name: "Leo", logo_description: "Logo del restaurante Leo Cocina y Cava, enfocado en ingredientes colombianos" },
  { id: "el_rancherito", name: "El Rancherito", logo_description: "Logo tradicional del restaurante El Rancherito" },
  { id: "crepes_waffles", name: "Crepes & Waffles", logo_description: "Logo icónico de Crepes & Waffles" },
  { id: "wok", name: "Wok", logo_description: "Logo del restaurante Wok con inspiración asiática" }
];

export const categories = [
  { id: "appetizers", name: "Entradas" },
  { id: "main_courses", name: "Platos Fuertes" },
  { id: "soups", name: "Sopas" },
  { id: "salads", name: "Ensaladas" },
  { id: "burgers", name: "Hamburguesas" },
  { id: "pizza", name: "Pizza" },
  { id: "wraps", name: "Wraps" },
  { id: "desserts", name: "Postres" },
  { id: "drinks", name: "Bebidas" },
  { id: "colombian_specialties", name: "Especialidades Colombianas" }
];
