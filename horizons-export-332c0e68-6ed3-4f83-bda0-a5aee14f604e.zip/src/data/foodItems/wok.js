export const wokFoodItems = [
  {
    id: 109,
    name: "Pad Thai de Camarones 'Auténtico Sabor Tailandés'",
    description: "Clásicos fideos de arroz tailandeses salteados en wok con camarones frescos, tofu, huevo revuelto, brotes de soya, cebollín, maní triturado y salsa de tamarindo agridulce.",
    price: 35000,
    image_description: "Plato generoso de Pad Thai de camarones salteados con fideos de arroz de color naranja claro brillante, brotes de soya frescos y blancos, maní picado esparcido, cebollín verde picado y un gajo de limón verde al lado, Wok, vista cenital",
    categoryId: "main_courses",
    restaurantId: "wok",
    isPopular: true,
    tags: ["Tailandés", "Fideos", "Mariscos", "Agridulce"]
  },
  {
    id: 110,
    name: "Sushi Roll California 'Clásico y Fresco' (8 piezas)",
    description: "Popular rollo de sushi (uramaki) con alga nori por dentro, relleno de palitos de cangrejo (kanikama), aguacate cremoso y pepino fresco, cubierto con sésamo tostado.",
    price: 28000,
    image_description: "Ocho piezas de sushi roll California perfectamente cortadas y alineadas, mostrando el relleno de cangrejo rosado, aguacate verde pálido y pepino blanco, con arroz por fuera y sésamo tostado blanco y negro, Wok, con jengibre encurtido y wasabi",
    categoryId: "main_courses",
    restaurantId: "wok",
    tags: ["Sushi", "Japonés", "Clásico", "Fresco"]
  },
  {
    id: 111,
    name: "Sopa Tom Yum Goong 'Picante y Aromática'",
    description: "Sopa tailandesa emblemática, picante y ácida, con un caldo aromático de hierba de limón, galanga y hojas de lima kaffir, con camarones grandes y champiñones.",
    price: 25000,
    image_description: "Sopa Tom Yum Goong de color rojo anaranjado intenso y brillante, aromática y humeante, con camarones grandes y rosados, champiñones laminados frescos y hierbas tailandesas (hojas de lima kaffir, galanga) flotando, Wok, en cuenco de cerámica",
    categoryId: "soups",
    restaurantId: "wok",
    tags: ["Sopa", "Tailandés", "Picante", "Aromática"]
  },
  {
    id: 112,
    name: "Ensalada Vietnamita de Mango Verde, Pollo Satay y Hierbabuena",
    description: "Ensalada refrescante y vibrante con tiras de mango verde crujiente, pollo marinado y asado en brocheta (satay), hierbabuena fresca, maní tostado y aderezo nuoc cham (agridulce y picante).",
    price: 30000,
    image_description: "Ensalada vietnamita muy colorida y fresca con tiras de mango verde pálido y crujiente, trozos de pollo satay dorado con marcas de parrilla, hojas de hierbabuena verde intenso y maní tostado picado, Wok, con aderezo nuoc cham en un cuenco pequeño",
    categoryId: "salads",
    restaurantId: "wok",
    tags: ["Ensalada", "Vietnamita", "Saludable", "Agripicante"]
  },
  {
    id: 113,
    name: "Arroz Frito Especial 'Wok de la Casa'",
    description: "Arroz jazmín salteado a alta temperatura en wok con una mezcla de pollo en cubos, camarones jugosos, cerdo asado (char siu), huevo revuelto, arvejas, zanahoria y cebollín.",
    price: 32000,
    image_description: "Arroz frito especial 'Wok de la Casa', con una mezcla abundante y visible de trozos de pollo dorado, camarones rosados y brillantes, cerdo asado rojizo en tiras, huevo revuelto amarillo, arvejas verdes y zanahoria naranja en cubos, salteados en wok, Wok",
    categoryId: "main_courses",
    restaurantId: "wok",
    tags: ["Arroz", "Asiático", "Mixto", "Salteado"]
  },
  {
    id: 114,
    name: "Curry Rojo Tailandés 'Intenso' con Pollo y Arroz Jazmín al Vapor",
    description: "Trozos de pollo tierno cocinados en una salsa de curry rojo tailandés intensa y cremosa (con leche de coco), pimientos, bambú y albahaca tailandesa, servido con arroz jazmín al vapor.",
    price: 33000,
    image_description: "Curry rojo tailandés espeso y de color rojo vibrante y cremoso, con trozos de pollo blanco tierno y vegetales (pimientos rojos y verdes en juliana, brotes de bambú), servido junto a un cuenco de arroz jazmín blanco y humeante, Wok, con hojas de albahaca tailandesa fresca",
    categoryId: "main_courses",
    restaurantId: "wok",
    isPopular: true,
    tags: ["Curry", "Tailandés", "Pollo", "Picante Moderado"]
  },
  {
    id: 115,
    name: "Té Helado de Lichi 'Dulce y Exótico'",
    description: "Té negro o verde helado, endulzado y aromatizado con el sabor dulce y floral del lichi, servido con hielo y trozos de fruta.",
    price: 12000,
    image_description: "Vaso alto de té helado de lichi, de color ámbar claro o verdoso pálido, con abundante hielo cristalino y varios lichis pelados, blancos y translúcidos, sin semilla flotando en la bebida, con una ramita de menta",
    categoryId: "drinks",
    restaurantId: "wok",
    tags: ["Té", "Frutal", "Refrescante", "Exótico"]
  },
  {
    id: 116,
    name: "Gyozas de Cerdo al Vapor 'Tradicionales Japonesas' (5 unidades)",
    description: "Empanaditas japonesas clásicas rellenas de carne de cerdo molida y vegetales finamente picados, cocidas al vapor y servidas con salsa ponzu.",
    price: 20000,
    image_description: "Cinco gyozas de cerdo al vapor, de masa fina y traslúcida con pliegues delicados, dispuestas en una pequeña canasta de bambú redonda sobre hojas de lechuga, con un cuenco de salsa ponzu oscura y cítrica al lado, Wok",
    categoryId: "appetizers",
    restaurantId: "wok",
    tags: ["Japonés", "Cerdo", "Entrada", "Al Vapor"]
  },
  {
    id: 117,
    name: "Ramen de Cerdo Chashu 'Tonkotsu Profundo'",
    description: "Auténtica sopa de fideos japonesa con un caldo tonkotsu (huesos de cerdo) rico y cremoso, fideos ramen, lonchas de cerdo marinado (chashu), huevo marinado (ajitsuke tamago), alga nori y cebollín.",
    price: 38000,
    image_description: "Tazón grande y profundo de ramen de cerdo chashu, con fideos amarillos sumergidos en caldo tonkotsu lechoso y opaco, lonchas de cerdo chashu enrolladas y tiernas, medio huevo marinado con yema naranja brillante, alga nori oscura y cebollín verde picado, Wok",
    categoryId: "soups",
    restaurantId: "wok",
    tags: ["Ramen", "Japonés", "Cerdo", "Sopa Contundente"]
  },
  {
    id: 118,
    name: "Banana Tempura 'Crujiente por Fuera, Suave por Dentro' con Helado de Té Verde Matcha",
    description: "Rodajas de banano maduro rebozadas en tempura ligera y fritas hasta quedar doradas y crujientes, servidas calientes con una bola de helado de té verde matcha.",
    price: 22000,
    image_description: "Varias rodajas de banana tempura dorada y muy crujiente, apiladas artísticamente sobre un plato blanco, acompañadas de una bola de helado de té verde matcha de color verde intenso y textura suave, Wok, con salsa de chocolate",
    categoryId: "desserts",
    restaurantId: "wok",
    tags: ["Postre", "Japonés", "Fritura", "Contraste"]
  },
  {
    id: 119,
    name: "Limonada Fresca con Hierbabuena y Jengibre 'Revitalizante'",
    description: "Limonada natural preparada con zumo de limón fresco, hojas de hierbabuena machacadas y un toque picante y aromático de jengibre fresco rallado.",
    price: 14000,
    image_description: "Vaso alto de limonada refrescante y ligeramente turbia, con abundantes hojas de hierbabuena fresca verde y finas hebras de jengibre amarillo pálido visibles, con hielo y una rodaja de limón en el borde",
    categoryId: "drinks",
    restaurantId: "wok",
    tags: ["Limonada", "Refrescante", "Natural", "Digestiva"]
  },
  {
    id: 120,
    name: "Edamames al Vapor con Sal Marina 'Snack Saludable'",
    description: "Vainas de soya tiernas cocidas al vapor en su punto y espolvoreadas generosamente con cristales de sal marina.",
    price: 15000,
    image_description: "Porción generosa de edamames verdes y brillantes al vapor en un cuenco rústico de cerámica oscura, con granos de sal marina gruesa y blanca visibles sobre las vainas, Wok, listos para comer",
    categoryId: "appetizers",
    restaurantId: "wok",
    tags: ["Vegetariano", "Saludable", "Japonés", "Snack"]
  }
];