export const elRancheritoFoodItems = [
  {
    id: 85,
    name: "Bandeja Paisa 'La Original del Arriero'",
    description: "Plato insignia antioqueño en su máxima expresión: frijoles cargamanto, arroz blanco, carne molida o en polvo, chicharrón carnudo, chorizo santarrosano, huevo frito, plátano maduro, aguacate y arepa.",
    price: 45000,
    image_description: "Bandeja paisa 'La Original del Arriero' rebosante y colorida de El Rancherito, con todos sus componentes tradicionales (frijoles espesos, arroz blanco graneado, carne molida, chicharrón de varias capas, chorizo curvo, huevo frito con yema líquida, tajadas de plátano maduro, aguacate cremoso y arepa blanca delgada) dispuestos de forma apetitosa en un plato grande ovalado de peltre",
    categoryId: "colombian_specialties",
    restaurantId: "el_rancherito",
    isPopular: true,
    tags: ["Colombiano", "Antioqueño", "Tradicional", "Abundante"]
  },
  {
    id: 86,
    name: "Sancocho Antioqueño de Tres Carnes 'El Trifásico'",
    description: "Sopa robusta y sustanciosa con tres carnes (res, cerdo y pollo), papa, yuca, plátano verde, mazorca y un toque de cilantro fresco.",
    price: 38000,
    image_description: "Sancocho antioqueño 'El Trifásico' humeante en plato hondo de barro, con trozos grandes de carne de res, costilla de cerdo y muslo de pollo, papa amarilla, yuca blanca, plátano verde y mazorca tierna, con abundante cilantro picado, El Rancherito",
    categoryId: "soups",
    restaurantId: "el_rancherito",
    tags: ["Sopa", "Colombiano", "Antioqueño", "Casero"]
  },
  {
    id: 87,
    name: "Chorizos Antioqueños 'De la Finca' con Arepa y Limón (x2)",
    description: "Dos chorizos antioqueños caseros, jugosos y bien condimentados, servidos con una arepa paisa tradicional (delgada y blanca) y cascos de limón.",
    price: 25000,
    image_description: "Dos chorizos antioqueños 'De la Finca', dorados y ligeramente curvos con marcas de parrilla, servidos con una arepa paisa blanca y redonda asada, y varios cascos de limón verde fresco, El Rancherito, sobre hoja de plátano",
    categoryId: "appetizers",
    restaurantId: "el_rancherito",
    tags: ["Cerdo", "Colombiano", "Antioqueño", "Artesanal"]
  },
  {
    id: 88,
    name: "Trucha a la Plancha 'Del Río' con Patacón Gigante",
    description: "Trucha fresca de la región, abierta y cocinada a la plancha hasta quedar dorada, servida con un patacón gigante y crujiente y ensalada.",
    price: 40000,
    image_description: "Trucha entera abierta a la plancha, de carne blanca y piel dorada con hierbas aromáticas, acompañada de un patacón muy grande, delgado y crujiente, y ensalada de lechuga crespa, tomate y cebolla morada, El Rancherito",
    categoryId: "main_courses",
    restaurantId: "el_rancherito",
    tags: ["Pescado", "Saludable", "Regional", "Plancha"]
  },
  {
    id: 89,
    name: "Mazamorra Antioqueña 'Con Panela Raspada y Leche Fresca'",
    description: "Postre o bebida tradicional antioqueña hecha de maíz blanco pelado y cocido, servida fría con panela raspada y leche fresca al gusto.",
    price: 15000,
    image_description: "Tazón de mazamorra antioqueña blanca y espesa con granos de maíz visibles, con un montoncito de panela raspada de color oscuro y textura granulada, y un pocillo de leche fresca al lado, El Rancherito, en ambiente rústico",
    categoryId: "desserts",
    restaurantId: "el_rancherito",
    tags: ["Postre", "Maíz", "Antioqueño", "Tradicional"]
  },
  {
    id: 90,
    name: "Claro 'Refresco de Maíz Tradicional'",
    description: "Bebida refrescante y muy tradicional de la región antioqueña, hecha a base de maíz cocido y endulzada ligeramente.",
    price: 10000,
    image_description: "Vaso de claro, bebida de maíz tradicional colombiana, de color blanco lechoso y textura ligera, servido frío en un vaso de vidrio sencillo, El Rancherito, con un fondo de finca antioqueña",
    categoryId: "drinks",
    restaurantId: "el_rancherito",
    tags: ["Bebida", "Maíz", "Antioqueño", "Refrescante"]
  },
  {
    id: 91,
    name: "Morcilla Antioqueña 'Con Arroz y Poleo' con Arepa",
    description: "Morcilla antioqueña casera, rellena de arroz y condimentada con poleo, servida en rodajas gruesas con una arepa paisa.",
    price: 22000,
    image_description: "Rodajas gruesas de morcilla antioqueña oscura y brillante con arroz blanco y hierbabuena o poleo visible en el relleno, servida junto a una arepa paisa redonda y blanca, El Rancherito, con ají casero",
    categoryId: "appetizers",
    restaurantId: "el_rancherito",
    tags: ["Cerdo", "Colombiano", "Antioqueño", "Embutido"]
  },
  {
    id: 92,
    name: "Carne Asada 'A Caballo' con Hogao y Papas Fritas Caseras",
    description: "Corte de res tierno a la parrilla, coronado con dos huevos fritos ('a caballo'), bañado en hogao (salsa criolla) y acompañado de papas fritas caseras.",
    price: 42000,
    image_description: "Carne asada (lomo de res) jugosa y bien marcada por la parrilla, con dos huevos fritos encima (yemas líquidas y claras crujientes), abundante hogao casero rojo y papas fritas rústicas y doradas, El Rancherito",
    categoryId: "main_courses",
    restaurantId: "el_rancherito",
    tags: ["Carne", "Parrilla", "Antioqueño", "Contundente"]
  },
  {
    id: 93,
    name: "Frijoles con Garra de Chicharrón 'Los Meros Meros'",
    description: "Porción generosa de frijoles antioqueños espesos y bien sazonados, acompañados de una garra grande y carnuda de chicharrón.",
    price: 30000,
    image_description: "Plato hondo de frijoles antioqueños espesos y oscuros (cargamanto), con una garra grande de chicharrón con varias capas de carne y piel crujiente y dorada, El Rancherito, con arroz y tajadas de maduro al lado",
    categoryId: "colombian_specialties",
    restaurantId: "el_rancherito",
    tags: ["Frijoles", "Cerdo", "Antioqueño", "Clásico"]
  },
  {
    id: 94,
    name: "Aguapanela con Queso 'Pa'l Frío'",
    description: "Bebida caliente y reconfortante de panela (jugo de caña de azúcar solidificado) con un trozo de queso campesino que se derrite en el fondo.",
    price: 12000,
    image_description: "Pocillo de barro con aguapanela caliente, oscura y humeante, con un trozo generoso de queso campesino blanco derritiéndose y estirándose en el interior, El Rancherito, ideal para clima frío",
    categoryId: "drinks",
    restaurantId: "el_rancherito",
    tags: ["Bebida", "Panela", "Tradicional", "Reconfortante"]
  },
  {
    id: 95,
    name: "Brevas con Arequipe 'Dulce Tentación'",
    description: "Brevas (higos tempranos) en almíbar dulce, abiertas y rellenas generosamente con arequipe (dulce de leche) cremoso.",
    price: 18000,
    image_description: "Varias brevas en almíbar de color oscuro y brillante, abiertas en forma de flor y rellenas con abundante arequipe claro y cremoso, postre tradicional colombiano, El Rancherito, servidas en plato blanco",
    categoryId: "desserts",
    restaurantId: "el_rancherito",
    tags: ["Postre", "Fruta", "Arequipe", "Casero"]
  },
  {
    id: 96,
    name: "Mondongo Antioqueño 'Bien Trancao'",
    description: "Sopa espesa y muy sustanciosa con callo (mondongo), carne de cerdo, papa, yuca, zanahoria, arvejas y verduras, condimentada con cilantro.",
    price: 35000,
    image_description: "Plato hondo de mondongo antioqueño 'Bien Trancao', espeso y lleno de trozos de callo blanco, carne de cerdo, papa amarilla, zanahoria en cubos y arvejas, con cilantro fresco picado encima y aguacate, El Rancherito",
    categoryId: "soups",
    restaurantId: "el_rancherito",
    tags: ["Sopa", "Colombiano", "Antioqueño", "Sustancioso"]
  }
];