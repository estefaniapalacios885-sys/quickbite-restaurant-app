export const elCieloFoodItems = [
  {
    id: 1,
    name: "Menú Degustación 'El Viaje'",
    description: "Experiencia culinaria multisensorial con varios pasos.",
    price: 150000,
    image_description: "Plato artístico y vanguardista del menú degustación 'El Viaje' de El Cielo, colores vibrantes y presentación molecular detallada, vista cenital",
    categoryId: "main_courses",
    restaurantId: "el_cielo",
    isPopular: true,
    tags: ["Alta Cocina", "Experiencia", "Innovador"]
  },
  {
    id: 2,
    name: "Trucha Arcoíris en Texturas",
    description: "Trucha preparada de diversas formas, resaltando su sabor.",
    price: 45000,
    image_description: "Plato de trucha arcoíris elegantemente presentado en El Cielo, con guarniciones coloridas y espuma delicada, primer plano",
    categoryId: "main_courses",
    restaurantId: "el_cielo",
    tags: ["Pescado", "Gourmet"]
  },
  {
    id: 3,
    name: "Cordero Lechal Confitado",
    description: "Cordero tierno cocinado lentamente, servido con guarnición de autor.",
    price: 55000,
    image_description: "Porción de cordero lechal confitado de El Cielo, piel extremadamente crujiente y carne sonrosada, sobre puré exótico de yuca y vainilla",
    categoryId: "main_courses",
    restaurantId: "el_cielo",
    tags: ["Cordero", "Gourmet"]
  },
  {
    id: 4,
    name: "Sopa de Maíz Ancestral",
    description: "Crema de maíz con toques ahumados y hierbas locales.",
    price: 25000,
    image_description: "Sopa de maíz ancestral, de un amarillo intenso y textura aterciopelada, servida en un cuenco de piedra volcánica en El Cielo, con brotes de cilantro",
    categoryId: "soups",
    restaurantId: "el_cielo",
    tags: ["Sopa", "Tradicional", "Innovador"]
  },
  {
    id: 5,
    name: "Ensalada de Flores Comestibles y Brotes",
    description: "Ensalada fresca y vibrante con aderezo cítrico.",
    price: 30000,
    image_description: "Ensalada muy colorida con una variedad de flores comestibles (violetas, capuchinas, borrajas) y brotes tiernos de El Cielo, aderezo brillante de maracuyá",
    categoryId: "salads",
    restaurantId: "el_cielo",
    tags: ["Ensalada", "Saludable", "Gourmet"]
  },
  {
    id: 6,
    name: "Postre de Chocolate Amazónico",
    description: "Variedades de chocolate de origen con frutas exóticas.",
    price: 35000,
    image_description: "Postre artístico de chocolate amazónico oscuro en diferentes texturas (mousse, tierra, teja) con frutas exóticas como copoazú y arazá de El Cielo",
    categoryId: "desserts",
    restaurantId: "el_cielo",
    isPopular: true,
    tags: ["Chocolate", "Postre", "Exótico"]
  },
  {
    id: 7,
    name: "Cóctel de Autor 'Cielo Rojo'",
    description: "Cóctel refrescante con licores premium y frutas tropicales.",
    price: 28000,
    image_description: "Cóctel 'Cielo Rojo' de un rojo intenso y vibrante, elegantemente servido en copa alta con garnish de flor de hibisco y borde de sal de hormiga culona en El Cielo",
    categoryId: "drinks",
    restaurantId: "el_cielo",
    tags: ["Cóctel", "Premium"]
  },
  {
    id: 8,
    name: "Tartar de Res Curada",
    description: "Carne de res curada y picada finamente, con yema de huevo y aliños.",
    price: 38000,
    image_description: "Tartar de res curada de El Cielo, presentado de forma circular impecable con una yema de huevo de codorniz cruda encima y microverdes de mostaza, sobre una tostada de pan de masa madre",
    categoryId: "appetizers",
    restaurantId: "el_cielo",
    tags: ["Carne", "Entrada"]
  },
  {
    id: 9,
    name: "Ceviche de Pescado Blanco con Leche de Tigre de Maracuyá",
    description: "Fresco ceviche con un toque tropical.",
    price: 36000,
    image_description: "Ceviche de pescado blanco fresco (corvina) con leche de tigre de maracuyá amarilla y vibrante, servido en copa de martini con chips de plátano verde en El Cielo",
    categoryId: "appetizers",
    restaurantId: "el_cielo",
    tags: ["Pescado", "Ceviche", "Fresco"]
  },
  {
    id: 10,
    name: "Risotto de Hongos Silvestres y Trufa",
    description: "Risotto cremoso con variedad de hongos y aceite de trufa.",
    price: 48000,
    image_description: "Risotto cremoso de hongos silvestres variados (porcini, shiitake, oronjas) con lascas finas de trufa negra de El Cielo y parmesano Reggiano rallado, decorado con perejil",
    categoryId: "main_courses",
    restaurantId: "el_cielo",
    tags: ["Risotto", "Vegetariano", "Gourmet"]
  },
  {
    id: 11,
    name: "Café Especial de Origen Único",
    description: "Selección de cafés colombianos de una sola finca, preparados por barista.",
    price: 15000,
    image_description: "Taza de café especial de origen único colombiano (Geisha o Bourbon Rosado) con arte latte complejo (cisne o rosetta) en El Cielo, servido con una pequeña galleta artesanal",
    categoryId: "drinks",
    restaurantId: "el_cielo",
    tags: ["Café", "Colombiano", "Origen Único"]
  },
  {
    id: 12,
    name: "Agua Mineral de Manantial Volcánico",
    description: "Agua pura de manantial de origen volcánico, ligeramente gasificada.",
    price: 10000,
    image_description: "Elegante botella de vidrio oscuro de agua mineral de manantial volcánico con etiqueta minimalista y burbujas finas, servida con una rodaja de limón",
    categoryId: "drinks",
    restaurantId: "el_cielo",
    tags: ["Bebida", "Natural", "Premium"]
  }
];