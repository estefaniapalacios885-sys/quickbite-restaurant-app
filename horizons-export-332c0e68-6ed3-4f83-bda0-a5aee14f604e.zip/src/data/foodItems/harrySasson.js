export const harrySassonFoodItems = [
  {
    id: 25,
    name: "Robalo a la Plancha con Puerros Confitados y Almendras",
    description: "Filete de robalo fresco cocinado a la plancha, acompañado de puerros dulces confitados y almendras tostadas.",
    price: 70000,
    image_description: "Filete de robalo blanco y nacarado a la plancha con piel crujiente, sobre una cama de puerros confitados caramelizados y almendras laminadas tostadas, presentación elegante y minimalista de Harry Sasson",
    categoryId: "main_courses",
    restaurantId: "harry_sasson",
    isPopular: true,
    tags: ["Pescado", "Alta Cocina", "Saludable", "Elegante"]
  },
  {
    id: 26,
    name: "Steak Pimienta Clásico 'Au Poivre'",
    description: "Lomo de res sellado en costra de pimienta negra, en salsa cremosa de pimienta, con papas a la francesa delgadas.",
    price: 75000,
    image_description: "Steak pimienta 'Au Poivre' jugoso y dorado con una costra oscura de granos de pimienta molida, bañado en salsa cremosa de coñac, acompañado de papas fritas delgadas y crujientes apiladas en Harry Sasson",
    categoryId: "main_courses",
    restaurantId: "harry_sasson",
    tags: ["Carne", "Clásico", "Francés", "Gourmet"]
  },
  {
    id: 27,
    name: "Carpaccio de Res con Rúgula, Parmesano y Alcaparras",
    description: "Finas láminas de res cruda aliñadas con aceite de oliva extra virgen, rúgula fresca, lascas de parmesano Reggiano y alcaparras baby.",
    price: 40000,
    image_description: "Carpaccio de res fresco y de color rojo intenso, elegantemente dispuesto en un plato blanco grande, con rúgula verde brillante, lascas de queso parmesano Reggiano y pequeñas alcaparras baby, Harry Sasson",
    categoryId: "appetizers",
    restaurantId: "harry_sasson",
    tags: ["Carne", "Entrada", "Italiano", "Fino"]
  },
  {
    id: 28,
    name: "Sopa de Cebolla Gratinada 'Traditionnelle'",
    description: "Clásica sopa francesa con cebolla caramelizada lentamente, caldo de res y costra de queso Gruyère tostado.",
    price: 35000,
    image_description: "Sopa de cebolla gratinada 'Traditionnelle' en cuenco de cerámica marrón oscuro, con una costra de queso Gruyère dorada, burbujeante y muy apetitosa, con perejil picado, Harry Sasson",
    categoryId: "soups",
    restaurantId: "harry_sasson",
    tags: ["Sopa", "Francés", "Clásico", "Reconfortante"]
  },
  {
    id: 29,
    name: "Ensalada Niçoise con Atún Fresco Sellado a la Perfección",
    description: "Ensalada completa con atún rojo fresco apenas sellado, huevo duro, aceitunas Kalamata, judías verdes, tomates cherry y anchoas.",
    price: 48000,
    image_description: "Ensalada Niçoise colorida y abundante con trozos de atún fresco sellado (rosado por dentro y costra tostada), huevo cocido partido por la mitad, aceitunas Kalamata enteras y vegetales frescos y crujientes, Harry Sasson",
    categoryId: "salads",
    restaurantId: "harry_sasson",
    tags: ["Ensalada", "Atún", "Francés", "Completa"]
  },
  {
    id: 30,
    name: "Milhoja de Arequipe 'Celestial'",
    description: "Capas finas y crujientes de hojaldre caramelizado, intercaladas con arequipe suave y crema pastelera ligera.",
    price: 30000,
    image_description: "Milhoja de arequipe 'Celestial', muy alta y delicada, con múltiples capas de hojaldre dorado y crujiente y crema de arequipe colombiano, espolvoreada con azúcar glas, Harry Sasson, vista lateral",
    categoryId: "desserts",
    restaurantId: "harry_sasson",
    isPopular: true,
    tags: ["Postre", "Arequipe", "Hojaldre", "Delicado"]
  },
  {
    id: 31,
    name: "Vino Tinto Reserva 'Selección del Sommelier' (Copa)",
    description: "Copa de vino tinto reserva cuidadosamente seleccionado por el sommelier de la casa, de una bodega reconocida.",
    price: 35000,
    image_description: "Copa de vino tinto reserva elegante, de color rubí profundo con reflejos granate, servida en una copa de cristal fino tipo Bordeaux en Harry Sasson",
    categoryId: "drinks",
    restaurantId: "harry_sasson",
    tags: ["Vino", "Premium", "Reserva"]
  },
  {
    id: 32,
    name: "Pulpo a la Parrilla con Papas Nativas y Pimentón Ahumado",
    description: "Tentáculos de pulpo tierno a la parrilla con marcas de grill, chimichurri de la casa y papas nativas de colores salteadas con pimentón ahumado.",
    price: 65000,
    image_description: "Pulpo a la parrilla tierno y dorado con marcas de la parrilla bien definidas, servido con papas nativas de colores vibrantes (moradas, rojas, amarillas) y un toque de pimentón ahumado en polvo, Harry Sasson",
    categoryId: "main_courses",
    restaurantId: "harry_sasson",
    tags: ["Mariscos", "Parrilla", "Mediterráneo"]
  },
  {
    id: 33,
    name: "Tostadas de Cangrejo Real y Aguacate Hass",
    description: "Carne de cangrejo real fresca y desmenuzada sobre tostadas de pan brioche, con aguacate Hass cremoso y un toque de mayonesa de sriracha.",
    price: 42000,
    image_description: "Dos tostadas crujientes de pan brioche dorado con abundante carne de cangrejo real blanca y rosada, aguacate Hass en láminas finas y un punto de mayonesa de sriracha naranja, Harry Sasson",
    categoryId: "appetizers",
    restaurantId: "harry_sasson",
    tags: ["Mariscos", "Entrada", "Fresco", "Lujoso"]
  },
  {
    id: 34,
    name: "Risotto de Langostinos Tigre y Limón Amarillo",
    description: "Risotto Arborio cremoso con langostinos tigre jugosos, ralladura de limón amarillo fresco y un toque de vino blanco.",
    price: 68000,
    image_description: "Risotto cremoso de color amarillo pálido con langostinos tigre grandes y rosados dispuestos en círculo, decorado con perejil fresco picado y abundante ralladura de limón amarillo, Harry Sasson",
    categoryId: "main_courses",
    restaurantId: "harry_sasson",
    tags: ["Risotto", "Mariscos", "Italiano", "Cremoso"]
  },
  {
    id: 35,
    name: "Gin Tonic 'Botánico' Clásico",
    description: "Gin premium infusionado con botánicos, tónica premium y una rodaja de pepino o pomelo rosado.",
    price: 30000,
    image_description: "Gin tonic 'Botánico' clásico, refrescante en copa balón con abundante hielo cristalino, rodaja de pepino verde y bayas de enebro flotando, Harry Sasson, con burbujas visibles",
    categoryId: "drinks",
    restaurantId: "harry_sasson",
    tags: ["Cóctel", "Clásico", "Premium", "Refrescante"]
  },
  {
    id: 36,
    name: "Crème brûlée de Vainilla de Tahití",
    description: "Postre clásico francés con crema de vainilla de Tahití y una costra de caramelo perfectamente crujiente y delgada.",
    price: 28000,
    image_description: "Crème brûlée de vainilla de Tahití en ramekin blanco individual, con una costra de caramelo dorada y brillante, recién flameada y crujiendo, Harry Sasson, con una frambuesa fresca de decoración",
    categoryId: "desserts",
    restaurantId: "harry_sasson",
    tags: ["Postre", "Francés", "Clásico", "Vainilla"]
  }
];