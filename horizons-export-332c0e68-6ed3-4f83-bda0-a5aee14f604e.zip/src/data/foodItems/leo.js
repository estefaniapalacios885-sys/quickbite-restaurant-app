export const leoFoodItems = [
  {
    id: 73,
    name: "Menú Degustación 'Ciclo-Bioma Amazónico'",
    description: "Experiencia gastronómica completa que explora la biodiversidad del bioma amazónico colombiano a través de múltiples pasos.",
    price: 200000,
    image_description: "Plato artístico y minimalista del menú 'Ciclo-Bioma Amazónico' de Leo, resaltando ingredientes nativos como gusano mojojoy blanco y brillante, y frutas exóticas como copoazú en esferas, sobre una base de hoja de plátano",
    categoryId: "main_courses",
    restaurantId: "leo",
    isPopular: true,
    tags: ["Alta Cocina", "Colombiano", "Biodiversidad", "Amazónico"]
  },
  {
    id: 74,
    name: "Pescado Amazónico 'Gamitana' en Hoja de Bijao con Yuca",
    description: "Pescado de río Gamitana cocido al vapor en hoja de bijao con hierbas aromáticas locales y servido con yuca cocida.",
    price: 70000,
    image_description: "Pescado amazónico 'Gamitana' envuelto y cocido en hoja de bijao verde oscuro, atado con fibra natural, servido cerrado junto a trozos de yuca blanca y humeante, Leo Cocina y Cava, con ají amazónico al lado",
    categoryId: "main_courses",
    restaurantId: "leo",
    tags: ["Pescado", "Amazónico", "Colombiano", "Tradicional"]
  },
  {
    id: 75,
    name: "Territorio de Insectos Comestibles: Hormigas, Mojojoy y Tantarrias",
    description: "Degustación guiada de insectos comestibles de diferentes regiones de Colombia: hormigas culonas santandereanas, mojojoy amazónico y tantarrias.",
    price: 50000,
    image_description: "Plato de degustación con diferentes insectos comestibles: hormigas culonas grandes y tostadas de color marrón oscuro, gusanos mojojoy blancos y gruesos asados, y pequeñas tantarrias negras, presentación audaz y cultural sobre una hoja de plátano, Leo",
    categoryId: "appetizers",
    restaurantId: "leo",
    tags: ["Insectos", "Exótico", "Colombiano", "Cultural"]
  },
  {
    id: 76,
    name: "Sopa de Cangrejo Azul del Pacífico con Leche de Coco",
    description: "Sopa intensa y sabrosa con carne de cangrejo azul fresco del Pacífico colombiano, enriquecida con leche de coco y ají dulce.",
    price: 45000,
    image_description: "Sopa de cangrejo azul del Pacífico, de color anaranjado claro y textura cremosa, con trozos visibles de carne de cangrejo desmenuzada y un toque de cilantro fresco y aceite de achiote, Leo",
    categoryId: "soups",
    restaurantId: "leo",
    tags: ["Sopa", "Mariscos", "Pacífico", "Leche de Coco"]
  },
  {
    id: 77,
    name: "Ensalada de Frutas Exóticas (Granadilla, Uchuva, Tomate de Árbol) y Semillas Nativas (Chía, Quinua)",
    description: "Variedad de frutas exóticas colombianas como granadilla, uchuva, tomate de árbol, combinadas con semillas ancestrales como chía y quinua crocante.",
    price: 40000,
    image_description: "Ensalada muy colorida con una variedad de frutas exóticas colombianas (granadilla abierta mostrando sus semillas, uchuvas amarillas en su capacho, tomate de árbol en rodajas rojas) y un mix de semillas nativas (chía negra, quinua inflada blanca) esparcidas, Leo, con flores comestibles",
    categoryId: "salads",
    restaurantId: "leo",
    tags: ["Ensalada", "Frutas", "Biodiversidad", "Saludable"]
  },
  {
    id: 78,
    name: "Postre de Cacao 100% Tumaco y Copoazú Fresco",
    description: "Diferentes texturas de cacao colombiano de origen Tumaco (100% pureza) contrastadas con la acidez refrescante del copoazú amazónico fresco.",
    price: 38000,
    image_description: "Postre elegante y oscuro con diferentes texturas de cacao 100% Tumaco (mousse aterciopelado, tierra crujiente, ganache brillante) y puntos de crema blanca de copoazú fresco y ácido, Leo, con nibs de cacao",
    categoryId: "desserts",
    restaurantId: "leo",
    isPopular: true,
    tags: ["Postre", "Chocolate", "Amazónico", "Origen"]
  },
  {
    id: 79,
    name: "Bebida Fermentada de Yuca Brava 'Chicha Indígena'",
    description: "Bebida ancestral fermentada a base de yuca brava, preparada según la tradición indígena, con un sabor único y ligeramente ácido.",
    price: 25000,
    image_description: "Vaso rústico de totumo con chicha tradicional indígena, bebida fermentada de yuca brava de color blanco lechoso y ligeramente espumosa, servida en Leo, con contexto cultural",
    categoryId: "drinks",
    restaurantId: "leo",
    tags: ["Bebida", "Fermentado", "Ancestral", "Cultural"]
  },
  {
    id: 80,
    name: "Carne de Chigüiro (Capibara) Curada y Ahumada con Casabe",
    description: "Carne de chigüiro de los Llanos Orientales, curada y ahumada con técnicas tradicionales, servida con tortas de casabe (yuca brava).",
    price: 65000,
    image_description: "Carne de chigüiro curada y ahumada, presentada en lonchas finas de color oscuro y textura fibrosa, acompañada de tortas redondas y delgadas de casabe crujiente, Leo, con mojo de ají llanero",
    categoryId: "main_courses",
    restaurantId: "leo",
    tags: ["Carne", "Exótico", "Llanos", "Ahumado"]
  },
  {
    id: 81,
    name: "Casabe Crocante con Ají de Frutas Amazónicas (Tucupí, Copoazú)",
    description: "Tortas delgadas y crujientes de yuca brava (casabe) para acompañar, servidas con pequeñas salsas picantes (ajíes) elaboradas con frutas amazónicas como tucupí y copoazú.",
    price: 35000,
    image_description: "Varias tortas delgadas y muy crujientes de casabe blanco, apiladas, acompañadas de dos pequeños cuencos de cerámica con ajíes de colores vibrantes (amarillo de copoazú, oscuro de tucupí) hechos de frutas amazónicas, Leo",
    categoryId: "appetizers",
    restaurantId: "leo",
    tags: ["Yuca", "Amazónico", "Picante", "Crocante"]
  },
  {
    id: 82,
    name: "Pirarucú Fresco con Tucupí Negro y Fariña de Yuca",
    description: "Filete de pirarucú, pez gigante del Amazonas, cocinado a la perfección y servido con una intensa salsa de tucupí negro (yuca brava fermentada) y fariña (harina de yuca) crocante.",
    price: 75000,
    image_description: "Filete grueso de pirarucú, pescado amazónico de carne blanca y jugosa, con una salsa oscura y brillante de tucupí negro intenso, y fariña amarilla y crujiente esparcida por encima, Leo, con brotes amazónicos",
    categoryId: "main_courses",
    restaurantId: "leo",
    tags: ["Pescado", "Amazónico", "Exótico", "Sabor Intenso"]
  },
  {
    id: 83,
    name: "Jugo de Arazá 'Néctar Amazónico'",
    description: "Jugo natural de arazá, fruta amazónica de sabor ácido y aroma penetrante, endulzado ligeramente.",
    price: 18000,
    image_description: "Vaso de jugo de arazá, de color amarillo pálido y textura ligeramente espesa, espumoso y muy refrescante, decorado con una rodaja de carambolo estrellado y una flor de borraja, Leo",
    categoryId: "drinks",
    restaurantId: "leo",
    tags: ["Jugo", "Fruta", "Amazónico", "Refrescante"]
  },
  {
    id: 84,
    name: "Helado de Hormiga Limonera con Tierra de Cacao",
    description: "Helado artesanal con el sorprendente toque cítrico de la hormiga limonera amazónica, servido sobre una 'tierra' comestible de cacao amargo.",
    price: 30000,
    image_description: "Bola de helado artesanal de color verde muy pálido con pequeñas hormigas limoneras negras visibles, servida sobre un lecho de crumble oscuro (tierra de cacao amargo), Leo, con una hoja de menta fresca",
    categoryId: "desserts",
    restaurantId: "leo",
    tags: ["Helado", "Insectos", "Exótico", "Cítrico"]
  }
];