export const elChatoFoodItems = [
  {
    id: 61,
    name: "Corazón de Res, Hormigas Culonas y Melón Cantaloupe",
    description: "Plato insignia audaz: finas láminas de corazón de res curado, hormigas culonas tostadas y esferas de melón cantaloupe.",
    price: 45000,
    image_description: "Plato innovador y artístico con finas láminas de corazón de res curado de color rojo oscuro, hormigas culonas grandes y crujientes, y esferas de melón cantaloupe naranja brillante, El Chato, sobre piedra laja",
    categoryId: "appetizers",
    restaurantId: "el_chato",
    isPopular: true,
    tags: ["Innovador", "Colombiano", "Autor", "Audaz"]
  },
  {
    id: 62,
    name: "Pollo de Patio Confitado con Arroz Meloso de Hongos",
    description: "Pollo de patio criado localmente, confitado lentamente hasta quedar tierno, servido con un arroz meloso y cremoso de hongos silvestres.",
    price: 60000,
    image_description: "Muslo de pollo de patio confitado, tierno y jugoso con piel dorada y crujiente, servido sobre un arroz meloso y oscuro de hongos silvestres colombianos (ceps, morillas), El Chato",
    categoryId: "main_courses",
    restaurantId: "el_chato",
    tags: ["Pollo", "Colombiano", "Autor", "Confort"]
  },
  {
    id: 63,
    name: "Trucha Curada en Sal de Zipaquirá con Suero Costeño y Alcaparras Fritas",
    description: "Trucha fresca delicadamente curada en sal de las minas de Zipaquirá, acompañada de puntos de suero costeño y alcaparras fritas crujientes.",
    price: 48000,
    image_description: "Trucha curada en finas láminas rosadas y brillantes, elegantemente presentada con puntos blancos de suero costeño cremoso y alcaparras fritas y abiertas esparcidas, El Chato, con flores comestibles",
    categoryId: "appetizers",
    restaurantId: "el_chato",
    tags: ["Pescado", "Colombiano", "Fresco", "Local"]
  },
  {
    id: 64,
    name: "Sopa de Tomate Ahumado con Queso Paipa y Crotones de Ajo",
    description: "Sopa reconfortante y aromática de tomates ahumados en casa, con trozos de queso Paipa derretido y crotones de pan al ajo.",
    price: 30000,
    image_description: "Sopa de tomate ahumado de color rojo profundo y textura rústica, con trozos de queso Paipa semiderretido y dorado, y crotones de pan de masa madre al ajo, El Chato",
    categoryId: "soups",
    restaurantId: "el_chato",
    tags: ["Sopa", "Vegetariano", "Colombiano", "Ahumado"]
  },
  {
    id: 65,
    name: "Ensalada de Vegetales de Temporada de la Huerta y Vinagreta de Gulupa y Miel",
    description: "Selección de los vegetales más frescos de la huerta (zanahorias baby, remolachas, rábanos) con una vinagreta agridulce de gulupa y miel local.",
    price: 35000,
    image_description: "Ensalada vibrante con una variedad de vegetales frescos de temporada (zanahorias baby multicolores, remolachas en espiral, rábanos finamente laminados), y una vinagreta de gulupa brillante y translúcida con semillas de gulupa visibles, El Chato",
    categoryId: "salads",
    restaurantId: "el_chato",
    tags: ["Ensalada", "Saludable", "Local", "De Temporada"]
  },
  {
    id: 66,
    name: "Postre de Merengue Roto, Lulo Ácido y Sabajón Artesanal",
    description: "Combinación de texturas y sabores colombianos: merengue crujiente roto, sorbete de lulo ácido y una crema de sabajón artesanal.",
    price: 32000,
    image_description: "Postre deconstruido con trozos de merengue blanco crujiente y etéreo, quenelle de sorbete de lulo verde pálido y brillante, y salsa amarilla de sabajón artesanal espesa, El Chato, con polvo de lulo",
    categoryId: "desserts",
    restaurantId: "el_chato",
    isPopular: true,
    tags: ["Postre", "Colombiano", "Innovador", "Texturas"]
  },
  {
    id: 67,
    name: "Cerveza Artesanal Local 'Bogotá Beer Company'",
    description: "Selección de cervezas artesanales de la reconocida cervecería local Bogotá Beer Company (ej. Chapinero Porter, Monserrate Roja).",
    price: 20000,
    image_description: "Vaso de cerveza artesanal local de Bogotá Beer Company, de color ámbar oscuro (Porter) o rojizo (Monserrate Roja), con espuma cremosa y densa, servida en El Chato con el logo de la cervecería visible",
    categoryId: "drinks",
    restaurantId: "el_chato",
    tags: ["Cerveza", "Artesanal", "Local", "Bogotana"]
  },
  {
    id: 68,
    name: "Cordero Asado Lentamente con Puré de Cubios y Chucrut Morado",
    description: "Cordero cocinado lentamente a baja temperatura hasta quedar muy tierno, acompañado de un puré suave de cubios andinos y chucrut de repollo morado casero.",
    price: 68000,
    image_description: "Pierna de cordero asado jugoso y de carne rosada que se deshace, servido con un puré de cubios de color claro y textura sedosa, y chucrut morado vibrante y fermentado, El Chato",
    categoryId: "main_courses",
    restaurantId: "el_chato",
    tags: ["Cordero", "Colombiano", "Andino", "Cocción Lenta"]
  },
  {
    id: 69,
    name: "Arepas de Maíz Pelao con Morcilla de Burgos y Aguacate Tatemado",
    description: "Pequeñas arepas de maíz pelao (maíz blanco trillado) con rodajas de morcilla de Burgos artesanal y trozos de aguacate tatemado (ligeramente quemado).",
    price: 38000,
    image_description: "Tres pequeñas arepas de maíz pelao blancas y rústicas, con rodajas de morcilla de Burgos oscura y brillante, y trozos de aguacate con marcas de tatemado y un toque de sal marina, El Chato",
    categoryId: "appetizers",
    restaurantId: "el_chato",
    tags: ["Arepa", "Colombiano", "Tradicional", "Fusión"]
  },
  {
    id: 70,
    name: "Pesca del Día Sostenible con Caldo de Hongos de Pino y Papa Nativa Morada",
    description: "Pescado fresco de origen sostenible (según disponibilidad), cocinado en un caldo aromático de hongos de pino y acompañado de papas nativas moradas.",
    price: 65000,
    image_description: "Filete de pesca del día (ej. corvina o pargo) blanco y jugoso en un caldo oscuro y aromático de hongos de pino, con papas nativas de color morado intenso y brotes de arveja, El Chato",
    categoryId: "main_courses",
    restaurantId: "el_chato",
    tags: ["Pescado", "Fresco", "Local", "Sostenible"]
  },
  {
    id: 71,
    name: "Infusión de Hierbas Andinas 'Aromas del Páramo'",
    description: "Mezcla reconfortante de hierbas aromáticas nativas de los Andes colombianos (como poleo, toronjil, manzanilla silvestre).",
    price: 15000,
    image_description: "Taza de infusión de hierbas andinas humeante y de color claro ambarino, con hierbas frescas visibles (hojas de poleo, flores de manzanilla), servida en una taza de cerámica artesanal rústica en El Chato",
    categoryId: "drinks",
    restaurantId: "el_chato",
    tags: ["Infusión", "Natural", "Andino", "Relajante"]
  },
  {
    id: 72,
    name: "Helado de Chicha de Maíz Morado y Crumble de Totumo",
    description: "Helado artesanal preparado con chicha de maíz morado fermentado, acompañado de un crumble crujiente hecho con la pulpa del totumo.",
    price: 28000,
    image_description: "Bola de helado artesanal de chicha de maíz morado, de un color violeta pálido y textura suave, con trocitos de crumble de totumo oscuro, rústico y crujiente, El Chato, decorado con una flor comestible",
    categoryId: "desserts",
    restaurantId: "el_chato",
    tags: ["Helado", "Colombiano", "Ancestral", "Innovador"]
  }
];