export const criterionFoodItems = [
  {
    id: 37,
    name: "Cochinillo Confitado 'Estilo Rausch' Piel Crocante",
    description: "Cochinillo lechal tierno y jugoso por dentro, con una piel increíblemente crujiente y dorada, especialidad de los hermanos Rausch.",
    price: 85000,
    image_description: "Porción generosa de cochinillo confitado dorado y muy crujiente, estilo Rausch, con carne tierna visible y jugosa, servido con puré de manzana especiado, Criterión",
    categoryId: "main_courses",
    restaurantId: "criterion",
    isPopular: true,
    tags: ["Cerdo", "Alta Cocina", "Especialidad", "Crujiente"]
  },
  {
    id: 38,
    name: "Langostinos Tigre al Ajillo 'Flambeados'",
    description: "Langostinos tigre grandes y carnosos, salteados en aceite de oliva con ajo laminado, guindilla y flambeados con brandy.",
    price: 70000,
    image_description: "Langostinos tigre grandes y jugosos al ajillo, con ajo laminado dorado y perejil fresco picado, servidos en cazuela de barro humeante con un toque de guindilla roja, Criterión",
    categoryId: "main_courses",
    restaurantId: "criterion",
    tags: ["Mariscos", "Español", "Ajo", "Picante Suave"]
  },
  {
    id: 39,
    name: "Foie Gras Mi-Cuit 'Hecho en Casa' con Compota de Higos al Oporto",
    description: "Delicado foie gras de pato hecho en casa, textura suave y untuosa, acompañado de compota de higos frescos al vino de Oporto.",
    price: 55000,
    image_description: "Foie gras mi-cuit elegante, cortado en una loncha gruesa y rosada, sobre tostada de pan brioche artesanal, con compota de higos oscuros y brillantes y reducción de Oporto, Criterión",
    categoryId: "appetizers",
    restaurantId: "criterion",
    tags: ["Foie Gras", "Francés", "Gourmet", "Delicatessen"]
  },
  {
    id: 40,
    name: "Bisque de Langosta 'Intensa y Cremosa'",
    description: "Sopa clásica francesa, cremosa y con un profundo sabor a langosta, enriquecida con un toque de coñac.",
    price: 45000,
    image_description: "Bisque de langosta rica, cremosa y de un color anaranjado intenso, decorada con un chorrito de crema fresca, perejil picado y un pequeño crostini con rouille, Criterión",
    categoryId: "soups",
    restaurantId: "criterion",
    tags: ["Sopa", "Mariscos", "Francés", "Clásica"]
  },
  {
    id: 41,
    name: "Ensalada de Pato Confitado y Lentejas Puy",
    description: "Pato confitado desmenuzado y crujiente sobre una cama de lentejas Puy tibias, con vinagreta de mostaza Dijon.",
    price: 50000,
    image_description: "Ensalada tibia con pato confitado desmenuzado y piel crujiente dorada, sobre lentejas Puy verdes y pequeñas, con vinagreta balsámica oscura y hojas de rúgula fresca, Criterión",
    categoryId: "salads",
    restaurantId: "criterion",
    tags: ["Ensalada", "Pato", "Francés", "Sustanciosa"]
  },
  {
    id: 42,
    name: "Soufflé de Grand Marnier 'Perfectamente Inflado'",
    description: "Soufflé ligero, aireado y caliente, con el sutil aroma y sabor del licor Grand Marnier, servido al momento.",
    price: 38000,
    image_description: "Soufflé de Grand Marnier alto, inflado y dorado pálido, recién salido del horno en su ramekin blanco, espolvoreado con azúcar glas y con una pequeña jarra de salsa de naranja al lado, Criterión",
    categoryId: "desserts",
    restaurantId: "criterion",
    isPopular: true,
    tags: ["Postre", "Francés", "Clásico", "Espectacular"]
  },
  {
    id: 43,
    name: "Champagne Brut 'Reserva Especial' (Copa)",
    description: "Copa de champagne francés brut de una casa prestigiosa, reserva especial con finas burbujas.",
    price: 60000,
    image_description: "Copa de champagne brut reserva especial, burbujeante y de color dorado pálido brillante, servida en una flauta elegante y alta en Criterión, con fondo oscuro",
    categoryId: "drinks",
    restaurantId: "criterion",
    tags: ["Champagne", "Premium", "Celebración"]
  },
  {
    id: 44,
    name: "Tartar de Atún Rojo 'Aleta Amarilla' con Aguacate y Sésamo Tostado",
    description: "Atún rojo aleta amarilla fresco, cortado en cubos pequeños, mezclado con aguacate cremoso, cebolla roja y aceite de sésamo tostado.",
    price: 52000,
    image_description: "Tartar de atún rojo fresco y brillante, de color rojo intenso, mezclado con aguacate verde en cubos y semillas de sésamo tostado blanco y negro, presentado en un aro con microbrotes, Criterión",
    categoryId: "appetizers",
    restaurantId: "criterion",
    tags: ["Atún", "Fresco", "Asiático", "Saludable"]
  },
  {
    id: 45,
    name: "Magret de Pato con Salsa de Frutos Rojos y Puré de Manzana",
    description: "Pechuga de pato sellada a la perfección (rosada por dentro), con piel crujiente, servida con una reducción de frutos rojos y un suave puré de manzana.",
    price: 72000,
    image_description: "Magret de pato rosado y jugoso, con piel dorada y crujiente, cortado en abanico y salseado con una reducción brillante de frutos rojos (frambuesas, moras), acompañado de puré de manzana y espárragos trigueros, Criterión",
    categoryId: "main_courses",
    restaurantId: "criterion",
    tags: ["Pato", "Francés", "Gourmet", "Agridulce"]
  },
  {
    id: 46,
    name: "Selección de Quesos Franceses 'Afinados'",
    description: "Tabla con una cuidada selección de quesos franceses afinados (brie, roquefort, comté), acompañados de nueces, uvas frescas y pan artesanal.",
    price: 48000,
    image_description: "Tabla elegante de madera con una selección de quesos franceses variados (pasta blanda con corteza enmohecida, azul intenso, curado de pasta dura), acompañada de uvas rojas y verdes, nueces pecanas y finas tostadas de pan de centeno, Criterión",
    categoryId: "appetizers",
    restaurantId: "criterion",
    tags: ["Queso", "Francés", "Para compartir", "Degustación"]
  },
  {
    id: 47,
    name: "Agua Mineral Francesa 'Perrier Fina Burbuja'",
    description: "Agua mineral natural con gas carbónico natural, de la fuente Perrier en Francia.",
    price: 12000,
    image_description: "Botella verde icónica de agua Perrier con su etiqueta distintiva y burbujas visibles, junto a un vaso con hielo y una rodaja de lima",
    categoryId: "drinks",
    restaurantId: "criterion",
    tags: ["Bebida", "Premium", "Francesa"]
  },
  {
    id: 48,
    name: "Tarta Tatin de Manzana 'Caramelizada a la Perfección'",
    description: "Clásica tarta francesa invertida de manzanas caramelizadas en mantequilla y azúcar, con base de hojaldre crujiente.",
    price: 35000,
    image_description: "Tarta Tatin de manzana individual, dorada y muy caramelizada con un brillo intenso, servida tibia con una quenelle de helado de vainilla artesanal con pintitas de vainilla, Criterión",
    categoryId: "desserts",
    restaurantId: "criterion",
    tags: ["Postre", "Francés", "Clásico", "Manzana"]
  }
];