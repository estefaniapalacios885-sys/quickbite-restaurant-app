export const andresCarnedeResFoodItems = [
  {
    id: 13,
    name: "Lomo al Trapo 'Legendario'",
    description: "Lomo de res envuelto en tela y cocido a las brasas, jugoso y tierno, receta secreta.",
    price: 65000,
    image_description: "Jugoso Lomo al Trapo 'Legendario' de Andrés Carne de Res, recién cortado mostrando el interior rosado intenso, servido en tabla de madera rústica con chimichurri verde brillante y papas criollas",
    categoryId: "colombian_specialties",
    restaurantId: "andres_carne_de_res",
    isPopular: true,
    tags: ["Carne", "Parrilla", "Colombiano", "Insignia"]
  },
  {
    id: 14,
    name: "Chicharrón Crocante 'Explosivo'",
    description: "Trozos de panceta de cerdo frita hasta quedar ultra crujiente, con arepa y limón.",
    price: 30000,
    image_description: "Porción muy generosa de chicharrón crocante y dorado 'Explosivo' de Andrés Carne de Res, con múltiples capas crujientes y carne visible, acompañado de arepitas blancas y gajos de limón verde",
    categoryId: "appetizers",
    restaurantId: "andres_carne_de_res",
    isPopular: true,
    tags: ["Cerdo", "Fritura", "Colombiano", "Popular"]
  },
  {
    id: 15,
    name: "Arepa de Choclo con Quesito 'Doble Crema'",
    description: "Arepa dulce de maíz tierno con abundante queso campesino doble crema derretido.",
    price: 20000,
    image_description: "Arepa de choclo dorada y muy tierna, de textura rústica, con una cantidad generosa de quesito doble crema derretido y burbujeante, servida en plato de barro en Andrés Carne de Res",
    categoryId: "appetizers",
    restaurantId: "andres_carne_de_res",
    tags: ["Arepa", "Maíz", "Vegetariano", "Tradicional"]
  },
  {
    id: 16,
    name: "Ajiaco Santafereño 'Completo y Auténtico'",
    description: "Sopa tradicional bogotana con pollo, tres tipos de papa, mazorca, alcaparras y crema de leche.",
    price: 40000,
    image_description: "Plato hondo de Ajiaco Santafereño 'Completo y Auténtico', humeante y espeso, de Andrés Carne de Res, con todos sus acompañamientos (arroz blanco, aguacate en lonchas, crema de leche en jarrita) visibles",
    categoryId: "soups",
    restaurantId: "andres_carne_de_res",
    tags: ["Sopa", "Pollo", "Colombiano", "Bogotano"]
  },
  {
    id: 17,
    name: "Mojarra Frita Entera 'Del Río Magdalena'",
    description: "Pescado mojarra grande y fresco, frito hasta la perfección, acompañado de patacones y ensalada costeña.",
    price: 48000,
    image_description: "Mojarra frita entera, muy dorada y crujiente, con cortes diagonales en su piel, servida con patacones grandes y amarillos, y ensalada fresca de repollo morado y zanahoria en Andrés Carne de Res",
    categoryId: "main_courses",
    restaurantId: "andres_carne_de_res",
    tags: ["Pescado", "Fritura", "Costeño", "Entero"]
  },
  {
    id: 18,
    name: "Posta Cartagenera 'Dulce Secreto'",
    description: "Carne de res en salsa oscura agridulce, receta tradicional de Cartagena con panela.",
    price: 52000,
    image_description: "Posta cartagenera 'Dulce Secreto' muy jugosa y bañada en salsa oscura brillante de panela de Andrés Carne de Res, acompañada de arroz con coco titoté y plátano maduro en tentación",
    categoryId: "colombian_specialties",
    restaurantId: "andres_carne_de_res",
    tags: ["Carne", "Colombiano", "Tradicional", "Cartagenero"]
  },
  {
    id: 19,
    name: "Empanadas Colombianas 'De la Abuela' (x3)",
    description: "Trío de empanadas de carne desmechada o pollo, con ají casero picantico.",
    price: 18000,
    image_description: "Trío de empanadas colombianas 'De la Abuela', doradas y de forma perfecta de media luna, servidas con un pequeño cuenco de salsa de ají casero rojo y limón verde",
    categoryId: "appetizers",
    restaurantId: "andres_carne_de_res",
    tags: ["Fritura", "Colombiano", "Casero"]
  },
  {
    id: 20,
    name: "Refajo 'Clásico Colombiano' (Cerveza con Colombiana)",
    description: "Bebida popular y refrescante, mezcla de cerveza rubia y gaseosa Colombiana.",
    price: 15000,
    image_description: "Vaso alto de refajo 'Clásico Colombiano', espumoso y de color ámbar claro, muy refrescante con cubos de hielo y una rodaja de naranja en el borde",
    categoryId: "drinks",
    restaurantId: "andres_carne_de_res",
    tags: ["Bebida", "Colombiano", "Tradicional", "Refrescante"]
  },
  {
    id: 21,
    name: "Merengón de Guanábana 'Gigante'",
    description: "Postre de merengue crujiente y alto, con abundante pulpa de guanábana fresca y crema batida.",
    price: 25000,
    image_description: "Merengón de guanábana 'Gigante', muy voluminoso y blanco, con capas visibles de merengue tostado, pulpa de guanábana fibrosa y crema batida espesa, en Andrés Carne de Res",
    categoryId: "desserts",
    restaurantId: "andres_carne_de_res",
    tags: ["Postre", "Fruta", "Colombiano", "Grande"]
  },
  {
    id: 22,
    name: "Parrillada 'Abundancia Total'",
    description: "Selección masiva de carnes a la parrilla: res, cerdo, pollo, chorizo, morcilla, y chunchullo.",
    price: 90000,
    image_description: "Parrillada 'Abundancia Total' con una gran variedad de carnes asadas (costillas de cerdo BBQ, lomo de res, punta de anca, muslos de pollo), chorizos dorados y morcilla oscura, servida en una gran bandeja de metal en Andrés Carne de Res",
    categoryId: "main_courses",
    restaurantId: "andres_carne_de_res",
    tags: ["Carne", "Parrilla", "Para compartir", "Festín"]
  },
  {
    id: 23,
    name: "Jugo de Lulo Fresco 'Acidito y Delicioso'",
    description: "Jugo natural de lulo, fruta ácida y muy refrescante, endulzado al gusto.",
    price: 12000,
    image_description: "Vaso de jugo de lulo espumoso y de un verde intenso y opaco, 'Acidito y Delicioso', con hielo y una rodaja de lulo con su piel verde en el borde",
    categoryId: "drinks",
    restaurantId: "andres_carne_de_res",
    tags: ["Jugo", "Fruta", "Natural", "Refrescante"]
  },
  {
    id: 24,
    name: "Patacones con Hogao 'Caseros y Crocantes'",
    description: "Plátano verde frito y aplastado dos veces, servido con salsa criolla de tomate y cebolla (hogao).",
    price: 22000,
    image_description: "Varios patacones dorados, grandes y muy crocantes, de forma irregular, servidos con un cuenco rebosante de hogao casero rojo y aromático con trozos de tomate y cebolla visibles",
    categoryId: "appetizers",
    restaurantId: "andres_carne_de_res",
    tags: ["Plátano", "Fritura", "Colombiano", "Casero"]
  }
];