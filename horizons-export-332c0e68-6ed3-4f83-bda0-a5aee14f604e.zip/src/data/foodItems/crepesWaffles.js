export const crepesWafflesFoodItems = [
  {
    id: 97,
    name: "Crepe de Pollo, Champiñones y Queso 'El Favorito'",
    description: "Clásico y siempre popular crepe salado relleno de pollo desmenuzado en salsa bechamel, champiñones frescos salteados y queso mozzarella derretido.",
    price: 28000,
    image_description: "Crepe dorado y doblado en forma de abanico, relleno generosamente de pollo desmenuzado en salsa blanca cremosa, champiñones laminados y salteados, y queso mozzarella visiblemente derretido y gratinado, Crepes & Waffles, con perejil picado",
    categoryId: "main_courses",
    restaurantId: "crepes_waffles",
    isPopular: true,
    tags: ["Crepe", "Pollo", "Clásico", "Comfort Food"]
  },
  {
    id: 98,
    name: "Waffle de Nutella y Banano 'Explosión de Sabor' con Helado de Vainilla Artesanal",
    description: "Waffle belga caliente y crujiente, cubierto generosamente con Nutella, rodajas de banano fresco y una bola de helado de vainilla artesanal de la casa.",
    price: 25000,
    image_description: "Waffle belga dorado y con profundos recuadros, cubierto con abundante Nutella brillante y esparcida, rodajas de banano fresco y maduro, y una bola grande de helado de vainilla artesanal con pintitas de vainilla derritiéndose lentamente, Crepes & Waffles",
    categoryId: "desserts",
    restaurantId: "crepes_waffles",
    isPopular: true,
    tags: ["Waffle", "Nutella", "Postre", "Indulgente"]
  },
  {
    id: 99,
    name: "Sopa Mexicana 'Con Todo' (Pollo, Aguacate, Totopos)",
    description: "Sopa de tortilla reconfortante con caldo de tomate y chile pasilla, pollo desmenuzado, aguacate en cubos, queso fresco, crema agria y tiras de tortilla frita.",
    price: 22000,
    image_description: "Sopa mexicana colorida en un cuenco grande de cerámica, con caldo rojo intenso, tiras de tortilla frita crujientes y amarillas, pollo desmenuzado, aguacate en cubos verdes, un copo de crema agria blanca y queso fresco desmoronado, Crepes & Waffles",
    categoryId: "soups",
    restaurantId: "crepes_waffles",
    tags: ["Sopa", "Mexicana", "Pollo", "Completa"]
  },
  {
    id: 100,
    name: "Ensalada de la Barra 'Crea tu Obra Maestra' (Pequeña)",
    description: "Acceso a la famosa barra de ensaladas para que armes tu propia combinación con una gran variedad de vegetales frescos, granos, proteínas y aderezos.",
    price: 20000,
    image_description: "Plato hondo con una ensalada muy variada y colorida, mostrando múltiples ingredientes frescos (lechugas mixtas, tomate cherry, zanahoria rallada, maíz dulce, huevo duro en rodajas, crutones) de la barra de ensaladas de Crepes & Waffles, con aderezo ranch visible",
    categoryId: "salads",
    restaurantId: "crepes_waffles",
    tags: ["Ensalada", "Saludable", "Personalizable", "Fresco"]
  },
  {
    id: 101,
    name: "Crepe de Lomito Pimienta 'Clásico Francés'",
    description: "Trozos de lomo de res tierno salteados en una salsa cremosa de pimienta negra y un toque de coñac, envueltos en un delicado crepe.",
    price: 32000,
    image_description: "Crepe delgado y dorado relleno de trozos de lomo de res tierno y jugoso, bañado en una salsa de pimienta negra oscura y cremosa, decorado con granos de pimienta verde y negra, Crepes & Waffles, servido en plato elegante",
    categoryId: "main_courses",
    restaurantId: "crepes_waffles",
    tags: ["Crepe", "Carne", "Salsa Pimienta", "Elegante"]
  },
  {
    id: 102,
    name: "Copa de Helado Artesanal 'Doble Tentación' (2 sabores)",
    description: "Generosa copa con dos sabores a elección de los deliciosos helados artesanales de la casa, elaborados con ingredientes naturales.",
    price: 18000,
    image_description: "Copa de vidrio alta y transparente con dos bolas grandes de helado artesanal de diferentes colores y texturas (ej. chocolate oscuro y fresa rosada con trozos), con una galleta barquillo crujiente y salsa de chocolate, Crepes & Waffles",
    categoryId: "desserts",
    restaurantId: "crepes_waffles",
    tags: ["Helado", "Artesanal", "Variedad", "Refrescante"]
  },
  {
    id: 103,
    name: "Jugo Natural de Fresa y Hierbabuena 'Frescura Total'",
    description: "Jugo preparado al momento con fresas frescas y hojas de hierbabuena, una combinación refrescante y digestiva.",
    price: 12000,
    image_description: "Vaso alto de jugo de fresa y hierbabuena, de color rojo vibrante con trocitos de fresa y hojitas de hierbabuena verde intenso visibles, con hielo y una rodaja de fresa en el borde",
    categoryId: "drinks",
    restaurantId: "crepes_waffles",
    tags: ["Jugo", "Fruta", "Natural", "Refrescante"]
  },
  {
    id: 104,
    name: "Pita Árabe con Pollo Shawarma 'Sabor Oriental'",
    description: "Pan pita caliente y suave, relleno de tiras de pollo marinado al estilo shawarma con especias orientales, vegetales frescos y salsa de yogur.",
    price: 26000,
    image_description: "Pan pita blanco y suave, abierto y relleno generosamente de pollo shawarma dorado y especiado con pimentón, con lechuga fresca, tomate en rodajas finas y salsa blanca de yogur con hierbabuena, Crepes & Waffles",
    categoryId: "wraps",
    restaurantId: "crepes_waffles",
    tags: ["Pita", "Pollo", "Árabe", "Especiado"]
  },
  {
    id: 105,
    name: "Crepe de Camarones al Curry 'Exótico y Suave'",
    description: "Camarones jugosos salteados en una salsa de curry amarillo suave y aromática con leche de coco y un toque de piña, envueltos en un crepe.",
    price: 30000,
    image_description: "Crepe delgado y dorado relleno de camarones rosados y jugosos en una salsa de curry amarillo claro y cremoso, con trocitos de piña caramelizada visibles y un toque de cilantro fresco, Crepes & Waffles",
    categoryId: "main_courses",
    restaurantId: "crepes_waffles",
    tags: ["Crepe", "Mariscos", "Curry", "Exótico"]
  },
  {
    id: 106,
    name: "Malteada de Oreo 'Irresistiblemente Cremosa'",
    description: "Malteada espesa y muy cremosa preparada con helado de vainilla y abundantes galletas Oreo trituradas, coronada con crema batida.",
    price: 16000,
    image_description: "Vaso alto y transparente mostrando una malteada de Oreo espesa y oscura con vetas blancas, con trozos de galleta visibles, coronada con un remolino alto de crema batida y una galleta Oreo entera clavada",
    categoryId: "drinks",
    restaurantId: "crepes_waffles",
    tags: ["Malteada", "Oreo", "Dulce", "Cremosa"]
  },
  {
    id: 107,
    name: "Brownie Melcochudo 'Chocolatoso' con Helado de Macadamia",
    description: "Brownie de chocolate oscuro, caliente y con centro melcochudo, acompañado de una bola de helado artesanal de macadamia.",
    price: 20000,
    image_description: "Cuadrado de brownie de chocolate oscuro, melcochudo y brillante con una costra ligeramente crujiente, con una bola de helado de macadamia de color crema con trozos de nuez, derritiéndose lentamente encima y salsa de chocolate, Crepes & Waffles",
    categoryId: "desserts",
    restaurantId: "crepes_waffles",
    tags: ["Postre", "Chocolate", "Clásico", "Intenso"]
  },
  {
    id: 108,
    name: "Café Latte 'Arte y Sabor'",
    description: "Café espresso de alta calidad con leche vaporizada y texturizada, a menudo decorado con arte latte por baristas expertos.",
    price: 10000,
    image_description: "Taza de cerámica blanca con un café latte mostrando un dibujo de arte latte bien definido (corazón o helecho complejo) en la espuma de leche cremosa y aterciopelada, con granos de café al lado",
    categoryId: "drinks",
    restaurantId: "crepes_waffles",
    tags: ["Café", "Clásico", "Arte Latte", "Aromático"]
  }
];