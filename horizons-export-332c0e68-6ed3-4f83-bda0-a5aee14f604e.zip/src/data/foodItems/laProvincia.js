export const laProvinciaFoodItems = [
  {
    id: 49,
    name: "Cazuela de Mariscos a la Marinera 'Tradición Costeña'",
    description: "Abundante cazuela con variedad de mariscos frescos (camarones, calamares, mejillones, pescado) en una rica salsa de tomate, vino blanco y hierbas.",
    price: 60000,
    image_description: "Cazuela de mariscos humeante y rebosante de camarones grandes y rosados, calamares tiernos en anillos, mejillones en su concha negra, en una salsa roja espesa con hierbas frescas, La Provincia, servida en cazuela de barro",
    categoryId: "main_courses",
    restaurantId: "la_provincia",
    isPopular: true,
    tags: ["Mariscos", "Colombiano", "Costeño", "Abundante"]
  },
  {
    id: 50,
    name: "Arroz con Coco y Camarones 'Titoté Auténtico'",
    description: "Arroz cocinado en leche de coco (titoté) que le da un color oscuro y sabor único, con camarones salteados en ajo y plátano maduro frito.",
    price: 55000,
    image_description: "Plato generoso de arroz con coco oscuro (titoté) y brillante, con camarones rosados y jugosos salteados con ajo y perejil, y trozos de plátano maduro frito dorado y caramelizado, La Provincia",
    categoryId: "main_courses",
    restaurantId: "la_provincia",
    tags: ["Arroz", "Mariscos", "Costeño", "Tradicional"]
  },
  {
    id: 51,
    name: "Mote de Queso Costeño 'Como en Casa'",
    description: "Sopa espesa y reconfortante de ñame blanco con trozos de queso costeño salado y suero atollabuey.",
    price: 35000,
    image_description: "Mote de queso costeño tradicional, espeso y de color blanco cremoso, con trozos grandes de queso costeño derretido y elástico, y un chorrito de suero atollabuey, La Provincia, con un toque de cilantro",
    categoryId: "soups",
    restaurantId: "la_provincia",
    tags: ["Sopa", "Colombiano", "Costeño", "Casero"]
  },
  {
    id: 52,
    name: "Pargo Rojo Frito Entero 'Crujiente y Jugoso'",
    description: "Pargo rojo grande y fresco, frito entero hasta quedar dorado y crujiente por fuera, jugoso por dentro, acompañado de patacones, arroz con coco y ensalada.",
    price: 65000,
    image_description: "Pargo rojo frito entero, de tamaño impresionante, dorado y muy crujiente con aletas extendidas, servido con patacones grandes y amarillos, porción de arroz con coco blanco y ensalada fresca de lechuga y tomate, La Provincia",
    categoryId: "main_courses",
    restaurantId: "la_provincia",
    tags: ["Pescado", "Fritura", "Costeño", "Completo"]
  },
  {
    id: 53,
    name: "Ensalada de Palmitos Frescos, Aguacate y Mango",
    description: "Fresca combinación de palmitos de cangrejo, aguacate cremoso, cubos de mango dulce, lechuga y vinagreta cítrica de la casa.",
    price: 38000,
    image_description: "Ensalada fresca y tropical con palmitos de cangrejo blancos y tiernos, trozos de aguacate verde cremoso, cubos de mango amarillo y naranja, sobre un lecho de lechuga variada y crujiente, La Provincia, con aderezo de cilantro",
    categoryId: "salads",
    restaurantId: "la_provincia",
    tags: ["Ensalada", "Saludable", "Fresco", "Tropical"]
  },
  {
    id: 54,
    name: "Enyucado Costeño 'Receta Original'",
    description: "Torta densa y dulce de yuca rallada, coco, queso costeño y anís, postre tradicional de la costa Caribe colombiana.",
    price: 25000,
    image_description: "Porción triangular de enyucado costeño, torta densa y dorada por fuera, húmeda por dentro, con sabor a coco tostado y anís, La Provincia, servida en plato de cerámica",
    categoryId: "desserts",
    restaurantId: "la_provincia",
    isPopular: true,
    tags: ["Postre", "Yuca", "Colombiano", "Tradicional"]
  },
  {
    id: 55,
    name: "Jugo de Corozo 'Rojo Pasión'",
    description: "Jugo refrescante y ligeramente ácido de corozo, pequeña fruta roja típica de la costa, endulzado al gusto.",
    price: 12000,
    image_description: "Vaso de jugo de corozo de color rojo intenso y brillante, con hielo picado y una rodaja de limón verde para decorar, servido en un vaso alto y transparente",
    categoryId: "drinks",
    restaurantId: "la_provincia",
    tags: ["Jugo", "Fruta", "Costeño", "Exótico"]
  },
  {
    id: 56,
    name: "Carimañolas de Carne Desmechada (x3)",
    description: "Frituras de masa de yuca suave por dentro y crujiente por fuera, rellenas de carne desmechada guisada.",
    price: 20000,
    image_description: "Trío de carimañolas doradas y de forma ovalada alargada, crujientes por fuera y suaves por dentro, con un pequeño cuenco de suero costeño blanco y espeso para acompañar, La Provincia",
    categoryId: "appetizers",
    restaurantId: "la_provincia",
    tags: ["Yuca", "Fritura", "Costeño", "Relleno"]
  },
  {
    id: 57,
    name: "Sancocho de Pescado 'Levanta Muertos'",
    description: "Sopa robusta y sustanciosa con trozos de pescado fresco (como bocachico o similar), yuca, plátano verde, ñame y cilantro.",
    price: 40000,
    image_description: "Sancocho de pescado reconfortante y caliente en plato hondo de loza, con trozos generosos de pescado blanco, yuca tierna, plátano verde cocido y cilantro fresco picado abundantemente, La Provincia",
    categoryId: "soups",
    restaurantId: "la_provincia",
    tags: ["Sopa", "Pescado", "Costeño", "Sustancioso"]
  },
  {
    id: 58,
    name: "Filete de Mero en Salsa de Mariscos 'Del Chef'",
    description: "Filete de mero fresco y jugoso, bañado en una rica y cremosa salsa con camarones, calamares y trocitos de langosta.",
    price: 70000,
    image_description: "Filete de mero blanco y jugoso, cubierto generosamente con una salsa cremosa de mariscos (camarones grandes y calamares en anillos visibles), decorado con perejil fresco y un toque de pimentón rojo, La Provincia",
    categoryId: "main_courses",
    restaurantId: "la_provincia",
    tags: ["Pescado", "Mariscos", "Gourmet", "Cremoso"]
  },
  {
    id: 59,
    name: "Limonada de Coco 'Cremosa y Tropical'",
    description: "Limonada preparada con zumo de limón fresco, leche de coco y coco rallado, resultando en una bebida cremosa y muy refrescante.",
    price: 15000,
    image_description: "Vaso alto de limonada de coco blanca, espesa y espumosa, con coco rallado tostado en el borde y una rodaja de limón, muy tropical y refrescante, con fondo playero",
    categoryId: "drinks",
    restaurantId: "la_provincia",
    tags: ["Bebida", "Coco", "Refrescante", "Tropical"]
  },
  {
    id: 60,
    name: "Cocadas 'Tradicionales de la Costa' (x4)",
    description: "Pequeños dulces de coco rallado horneados hasta quedar dorados por fuera y suaves por dentro.",
    price: 18000,
    image_description: "Cuatro cocadas pequeñas, doradas y con textura rústica de coco rallado caramelizado, presentadas en un platillo de hojas de palma tejida",
    categoryId: "desserts",
    restaurantId: "la_provincia",
    tags: ["Postre", "Coco", "Tradicional", "Bocado Dulce"]
  }
];