
export { restaurants, categories } from './restaurantsAndCategories';
export { foodItems } from './foodItemsData';
