import { elCieloFoodItems } from './foodItems/elCielo';
import { andresCarnedeResFoodItems } from './foodItems/andresCarnedeRes';
import { harrySassonFoodItems } from './foodItems/harrySasson';
import { criterionFoodItems } from './foodItems/criterion';
import { laProvinciaFoodItems } from './foodItems/laProvincia';
import { elChatoFoodItems } from './foodItems/elChato';
import { leoFoodItems } from './foodItems/leo';
import { elRancheritoFoodItems } from './foodItems/elRancherito';
import { crepesWafflesFoodItems } from './foodItems/crepesWaffles';
import { wokFoodItems } from './foodItems/wok';

export const foodItems = [
  ...elCieloFoodItems,
  ...andresCarnedeResFoodItems,
  ...harrySassonFoodItems,
  ...criterionFoodItems,
  ...laProvinciaFoodItems,
  ...elChatoFoodItems,
  ...leoFoodItems,
  ...elRancheritoFoodItems,
  ...crepesWafflesFoodItems,
  ...wokFoodItems,
];