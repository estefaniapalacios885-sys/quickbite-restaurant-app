import React, { createContext, useState, useContext, useEffect } from 'react';
import { useToast } from "@/components/ui/use-toast";

const AuthContext = createContext();

export const useAuth = () => {
  return useContext(AuthContext);
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    const storedUser = localStorage.getItem('quickbite-currentUser');
    if (storedUser) {
      try {
        setCurrentUser(JSON.parse(storedUser));
      } catch (error) {
        console.error("Error parsing stored user:", error);
        localStorage.removeItem('quickbite-currentUser');
      }
    }
  }, []);

  const login = (email, password) => {
    const users = JSON.parse(localStorage.getItem('quickbite-users') || '[]');
    const user = users.find(u => u.email === email && u.password === password); 
    if (user) {
      const profile = JSON.parse(localStorage.getItem(`quickbite-profile-${user.email}`) || '{}');
      const userData = { ...user, ...profile };
      setCurrentUser(userData);
      localStorage.setItem('quickbite-currentUser', JSON.stringify(userData));
      toast({ title: "Inicio de sesión exitoso", description: `Bienvenido de nuevo, ${user.name}!` });
      return true;
    }
    toast({ title: "Error de inicio de sesión", description: "Correo o contraseña incorrectos.", variant: "destructive" });
    return false;
  };

  const signup = (name, email, password) => {
    const users = JSON.parse(localStorage.getItem('quickbite-users') || '[]');
    if (users.find(u => u.email === email)) {
      toast({ title: "Error de registro", description: "Este correo electrónico ya está en uso.", variant: "destructive" });
      return false;
    }
    const newUser = { name, email, password, avatarUrl: "" }; 
    users.push(newUser);
    localStorage.setItem('quickbite-users', JSON.stringify(users));
    
    const initialProfile = {
      name: newUser.name,
      email: newUser.email,
      phone: "",
      address: "",
      avatarUrl: "" 
    };
    localStorage.setItem(`quickbite-profile-${newUser.email}`, JSON.stringify(initialProfile));
    
    setCurrentUser(newUser);
    localStorage.setItem('quickbite-currentUser', JSON.stringify(newUser));
    toast({ title: "Registro exitoso", description: `¡Bienvenido a QuickTBite, ${name}!` });
    return true;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('quickbite-currentUser');
    toast({ title: "Sesión cerrada", description: "Has cerrado sesión exitosamente." });
  };

  const updateUserProfile = (profileData) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, ...profileData };
      setCurrentUser(updatedUser);
      localStorage.setItem('quickbite-currentUser', JSON.stringify(updatedUser));
      localStorage.setItem(`quickbite-profile-${currentUser.email}`, JSON.stringify(profileData));
    }
  };

  const value = {
    currentUser,
    login,
    signup,
    logout,
    updateUserProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};