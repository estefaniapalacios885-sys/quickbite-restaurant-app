import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

const CategoryFilter = ({ categories, activeCategory, onSelectCategory }) => {
  return (
    <div className="overflow-x-auto pb-2 -mx-4 px-4">
      <div className="flex space-x-2">
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button
            variant={activeCategory === "all" ? "default" : "outline"}
            className="rounded-full"
            onClick={() => onSelectCategory("all")}
          >
            All
          </Button>
        </motion.div>
        
        {categories.map((category) => (
          <motion.div
            key={category.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              variant={activeCategory === category.id ? "default" : "outline"}
              className="rounded-full"
              onClick={() => onSelectCategory(category.id)}
            >
              {category.name}
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default CategoryFilter;