import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Star } from "lucide-react";
import { formatCurrency } from "@/utils/formatCurrency";

const FoodCard = ({ food, onAddToCart }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col hover:shadow-xl transition-shadow duration-300"
    >
      <div className="relative h-48 w-full">
        <img 
          alt={food.name}
          className="w-full h-full object-cover"
         src="https://images.unsplash.com/photo-1590383276111-0392dfd402ac" />
        {food.isPopular && (
          <Badge
            variant="default"
            className="absolute top-3 right-3 bg-primary text-primary-foreground"
          >
            <Star className="h-3 w-3 mr-1" /> Popular
          </Badge>
        )}
      </div>
      <div className="p-5 flex flex-col flex-grow">
        <h3 className="text-xl font-semibold mb-2 truncate" title={food.name}>{food.name}</h3>
        <p className="text-sm text-muted-foreground mb-3 flex-grow line-clamp-2">
          {food.description}
        </p>
        <div className="flex items-center justify-between mb-4">
          <span className="text-xl font-bold text-primary">
            {formatCurrency(food.price)}
          </span>
          {food.tags && food.tags.length > 0 && (
            <Badge variant="secondary" className="hidden sm:inline-flex">{food.tags[0]}</Badge>
          )}
        </div>
        <Button
          onClick={() => onAddToCart(food)}
          className="w-full mt-auto bg-gradient-to-r from-primary to-orange-400 hover:from-primary/90 hover:to-orange-400/90 text-white"
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          Agregar al Carrito
        </Button>
      </div>
    </motion.div>
  );
};

export default FoodCard;