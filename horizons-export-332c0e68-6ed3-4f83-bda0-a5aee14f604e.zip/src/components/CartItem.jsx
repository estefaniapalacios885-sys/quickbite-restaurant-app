import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, Plus, Minus } from "lucide-react";
import { formatCurrency } from "@/utils/formatCurrency";

const CartItem = ({ item, onUpdateQuantity, onRemoveItem }) => {
  return (
    <div className="flex items-center py-4 border-b border-gray-200 last:border-b-0">
      <div className="w-16 h-16 rounded-md overflow-hidden mr-4 bg-gray-100">
        <img 
          alt={item.name}
          className="w-full h-full object-cover"
         src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
      </div>
      <div className="flex-grow">
        <h4 className="font-semibold text-sm mb-1">{item.name}</h4>
        <p className="text-xs text-muted-foreground mb-1">
          {formatCurrency(item.price)}
        </p>
        <div className="flex items-center mt-1">
          <Button
            variant="outline"
            size="icon"
            className="h-6 w-6"
            onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
          >
            <Minus className="h-3 w-3" />
          </Button>
          <Input
            type="number"
            value={item.quantity}
            onChange={(e) => onUpdateQuantity(item.id, parseInt(e.target.value) || 1)}
            className="h-6 w-10 text-center mx-1 px-0 border-transparent focus-visible:ring-0"
            readOnly 
          />
          <Button
            variant="outline"
            size="icon"
            className="h-6 w-6"
            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <div className="text-right ml-4">
        <p className="font-semibold text-sm">
          {formatCurrency(item.price * item.quantity)}
        </p>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 text-muted-foreground hover:text-destructive mt-1"
          onClick={() => onRemoveItem(item.id)}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default CartItem;