import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowLeft } from "lucide-react";

const OrderSuccess = ({ order, onBackToMenu }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-md mx-auto text-center py-8"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: "spring" }}
        className="mb-6 inline-flex items-center justify-center"
      >
        <CheckCircle className="h-16 w-16 text-green-500" />
      </motion.div>
      
      <h2 className="text-2xl font-bold mb-2">Order Confirmed!</h2>
      <p className="text-muted-foreground mb-6">
        Your order #{order.orderNumber} has been placed successfully.
      </p>
      
      <div className="bg-muted p-4 rounded-lg mb-6">
        <div className="text-sm text-left">
          <div className="mb-4">
            <h3 className="font-medium mb-2">Delivery Details</h3>
            <p>{order.customer.name}</p>
            <p>{order.customer.phone}</p>
            <p>{order.customer.address}</p>
          </div>
          
          <div>
            <h3 className="font-medium mb-2">Order Summary</h3>
            <ul className="space-y-1">
              {order.items.map((item) => (
                <li key={item.id} className="flex justify-between">
                  <span>
                    {item.quantity} × {item.name}
                  </span>
                  <span>${(item.price * item.quantity).toFixed(2)}</span>
                </li>
              ))}
            </ul>
            
            <div className="border-t mt-2 pt-2 font-medium flex justify-between">
              <span>Total</span>
              <span>${order.total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
      
      <p className="text-sm text-muted-foreground mb-6">
        We've sent a confirmation to your phone. You'll receive updates about your order status.
      </p>
      
      <Button onClick={onBackToMenu} className="gap-2">
        <ArrowLeft className="h-4 w-4" /> Back to Menu
      </Button>
    </motion.div>
  );
};

export default OrderSuccess;