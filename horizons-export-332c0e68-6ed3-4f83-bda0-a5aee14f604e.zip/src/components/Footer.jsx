import React from "react";
import { Link } from "react-router-dom";

const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/332c0e68-6ed3-4f83-bda0-a5aee14f604e/c763909eb150b242da22c76003417423.png";
const slogan = "UNIDOS POR EL SABOR";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
               <img src={logoUrl} alt="QuickTBite Logo" className="h-10" />
              <div className="flex flex-col">
                <span className="font-bold text-xl -mb-1">QUICKTBITE</span>
                <span className="text-xs text-primary font-medium">{slogan}</span>
              </div>
            </div>
            <p className="text-gray-400 mb-4 text-sm">
              Comida deliciosa entregada rápido a tu puerta.
            </p>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white transition-colors text-sm">Inicio</Link></li>
              <li><Link to="/menu" className="text-gray-400 hover:text-white transition-colors text-sm">Menú</Link></li>
              <li><Link to="/profile" className="text-gray-400 hover:text-white transition-colors text-sm">Perfil</Link></li>
              <li><Link to="/track-order" className="text-gray-400 hover:text-white transition-colors text-sm">Seguir Pedido</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Contáctanos</h3>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>Carrera 16 este #51b-249</li>
              <li>Teléfono: +57 3234063877</li>
              <li>Email: santy.usugagr@amigo.edu.co</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Horario de Atención</h3>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>Lunes - Viernes: 10:00 AM - 10:00 PM</li>
              <li>Sábado - Domingo: 11:00 AM - 11:00 PM</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 text-center text-gray-400 text-sm">
          <p className="mb-2">Creado por: Santy Usuga Graciano - Estefania Palacios Palacios</p>
          <p>&copy; {new Date().getFullYear()} QUICKTBITE. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;