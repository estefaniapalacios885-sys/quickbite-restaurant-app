import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { restaurants as restaurantDataList } from "@/data";


const RestaurantsSection = () => {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Restaurantes Colombianos Populares</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Descubre sabores auténticos de restaurantes reconocidos en Colombia.
          </p>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {restaurantDataList.map((restaurant, index) => (
            <motion.div
              key={restaurant.id || index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="bg-white p-4 rounded-xl shadow-sm hover:shadow-lg transition-all flex flex-col items-center text-center"
            >
              <div className="w-24 h-24 mb-3 rounded-full overflow-hidden bg-gray-100 flex items-center justify-center">
                <img  alt={`${restaurant.name} logo`} className="w-full h-full object-contain p-2" src="https://images.unsplash.com/photo-1590383276111-0392dfd402ac" />
              </div>
              <h3 className="font-semibold text-md mb-1">{restaurant.name}</h3>
              <Button variant="link" size="sm" asChild className="mt-auto">
                <Link to={`/menu?restaurant=${restaurant.id}`}>Ver Menú</Link>
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RestaurantsSection;