import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Star } from "lucide-react";

const popularItemsData = [
  {
    id: 85, // Bandeja Paisa from El Rancherito
    name: "Bandeja Paisa Tradicional",
    image_description: "Plato abundante de Bandeja Paisa colombiana con frijoles, arroz, carne, chicharrón, chorizo, huevo, plátano y aguacate",
    price: 45.00,
    rating: 4.9,
    restaurant: "El Rancherito"
  },
  {
    id: 13, // Lomo al Trapo from Andrés Carne de Res
    name: "Lomo al Trapo",
    image_description: "Jugoso Lomo al Trapo de Andrés Carne de Res, cocido a las brasas",
    price: 65.00,
    rating: 4.8,
    restaurant: "Andrés Carne de Res"
  },
  {
    id: 97, // Crepe de Pollo, Champiñones y Queso from Crepes & Waffles
    name: "Crepe de Pollo, Champiñones y Queso",
    image_description: "Delicioso crepe relleno de pollo, champiñones y queso de Crepes & Waffles",
    price: 28.00,
    rating: 4.7,
    restaurant: "Crepes & Waffles"
  }
];

const PopularItemsSection = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Platos Populares</h2>
          <Button variant="outline" asChild>
            <Link to="/menu">Ver Todos <ArrowRight className="ml-2 h-4 w-4" /></Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularItemsData.map((item, index) => (
            <motion.div
              key={item.id || index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all food-card"
            >
              <div className="h-48 overflow-hidden">
                <img  alt={item.name} className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-semibold text-lg">{item.name}</h3>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                    <span className="text-sm">{item.rating}</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mb-2">De: {item.restaurant}</p>
                <div className="flex justify-between items-center mt-4">
                  <span className="font-bold text-primary">${item.price.toFixed(2)}</span>
                  <Button size="sm" asChild>
                    <Link to={`/menu?item=${item.id}`}>Pedir Ahora</Link>
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PopularItemsSection;