import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Star, Clock } from "lucide-react";

const logoUrlHero = "https://storage.googleapis.com/hostinger-horizons-assets-prod/332c0e68-6ed3-4f83-bda0-a5aee14f604e/c763909eb150b242da22c76003417423.png";


const HeroSection = () => {
  return (
    <section className="relative pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      <div className="hero-gradient absolute inset-0 z-0 opacity-10"></div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
                QUICKTBITE <br />
                <span className="text-primary">UNIDOS POR EL SABOR</span>
              </h1>
              <p className="text-lg text-muted-foreground mb-8 max-w-md">
                Pide tus comidas favoritas de los mejores restaurantes y disfruta de una entrega rápida a tu puerta.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" asChild>
                  <Link to="/menu">
                    Pedir Ahora <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link to="/menu">Ver Menú</Link>
                </Button>
              </div>
              
              <div className="flex items-center gap-6 mt-10">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                  <div>
                    <div className="font-medium">4.8/5</div>
                    <div className="text-xs text-muted-foreground">Calificación de Clientes</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <div>
                    <div className="font-medium">30 min</div>
                    <div className="text-xs text-muted-foreground">Tiempo de Entrega</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
          
          <div className="md:w-1/2">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative flex justify-center items-center"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl w-3/4 md:w-full max-w-md">
                <img  alt="QuickTBite App Showcase" className="w-full h-auto rounded-2xl object-contain" src={logoUrlHero} />
              </div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="absolute -bottom-6 -left-6 glass-effect p-4 rounded-lg shadow-lg hidden md:flex"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-primary rounded-full p-2">
                    <img src={logoUrlHero} alt="Mini Logo" className="h-5 w-5 object-contain"/>
                  </div>
                  <div>
                    <div className="font-medium">100+ Platos</div>
                    <div className="text-xs text-muted-foreground">Para elegir</div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;