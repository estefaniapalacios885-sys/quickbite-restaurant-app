import React from "react";
import { motion } from "framer-motion";
import { Clock, Star, UtensilsCrossed } from "lucide-react";

const FeaturesSection = () => {
  const features = [
    {
      icon: <Clock className="h-10 w-10 text-primary" />,
      title: "Entrega Rápida",
      description: "Recibe tu comida en 30 minutos o menos, caliente y fresca."
    },
    {
      icon: <Star className="h-10 w-10 text-primary" />,
      title: "Comida de Calidad",
      description: "Nos asociamos con los mejores restaurantes para garantizar comidas de alta calidad."
    },
    {
      icon: <UtensilsCrossed className="h-10 w-10 text-primary" />,
      title: "Amplia Selección",
      description: "Elige entre cientos de platos de diversas cocinas."
    }
  ];

  return (
    <section className="py-16 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">¿Por qué elegir QuickBite?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Estamos comprometidos a brindar la mejor experiencia de entrega de comida con estas increíbles características.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;