import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const CtaSection = () => {
  return (
    <section className="py-16 bg-primary/10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="md:w-1/2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                ¿Hambriento? ¡Te tenemos cubierto!
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Descarga nuestra aplicación móvil para pedidos aún más rápidos y ofertas exclusivas.
              </p>
              <Button size="lg" asChild>
                <Link to="/menu">Pedir Ahora <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
            </motion.div>
          </div>
          
          <div className="md:w-1/2">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="rounded-xl overflow-hidden shadow-lg"
            >
              <img  alt="Mobile app interface" className="w-full h-auto" src="https://images.unsplash.com/photo-1601972602237-8c79241e468b" />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;