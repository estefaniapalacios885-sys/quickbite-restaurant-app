import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ShoppingCart, Menu, User, Home, UtensilsCrossed, MapPin as MapPinIcon, LogIn, LogOut, UserPlus } from 'lucide-react';
import { useAuth } from "@/contexts/AuthContext";

const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/332c0e68-6ed3-4f83-bda0-a5aee14f604e/c763909eb150b242da22c76003417423.png";
const slogan = "UNIDOS POR EL SABOR";

const Navbar = ({ cartItemsCount, onCartClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const getInitials = (name) => {
    if (!name) return "U";
    const nameParts = name.split(" ");
    if (nameParts.length > 1) {
      return (nameParts[0][0] + nameParts[1][0]).toUpperCase();
    }
    return nameParts[0][0].toUpperCase();
  }

  const handleLogout = () => {
    logout();
    navigate("/");
  };
  
  const userAvatar = currentUser?.avatarUrl || "";
  const userName = currentUser?.name || "Usuario";

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-white/90 backdrop-blur-md shadow-md py-2"
          : "bg-transparent py-4"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <img src={logoUrl} alt="QuickTBite Logo" className="h-10" />
            <div className="flex flex-col">
              <span className="font-bold text-xl -mb-1">QUICKTBITE</span>
              <span className="text-xs text-primary font-medium">{slogan}</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link to="/" className="font-medium hover:text-primary transition-colors">
              Inicio
            </Link>
            <Link to="/menu" className="font-medium hover:text-primary transition-colors">
              Menú
            </Link>
            {currentUser && (
              <Link to="/track-order" className="font-medium hover:text-primary transition-colors">
                Seguir Pedido
              </Link>
            )}
          </nav>

          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={onCartClick}
            >
              <ShoppingCart className="h-5 w-5" />
              <AnimatePresence>
                {cartItemsCount > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center"
                  >
                    {cartItemsCount}
                  </motion.div>
                )}
              </AnimatePresence>
            </Button>

            {currentUser ? (
              <Link to="/profile">
                <Avatar className="h-8 w-8 cursor-pointer">
                  <AvatarImage src={userAvatar} alt={userName} />
                  <AvatarFallback>
                    {getInitials(userName)}
                  </AvatarFallback>
                </Avatar>
              </Link>
            ) : (
              <div className="hidden md:flex items-center gap-2">
                <Button variant="ghost" size="sm" asChild>
                  <Link to="/login">Iniciar Sesión</Link>
                </Button>
                <Button size="sm" asChild>
                  <Link to="/signup">Crear Cuenta</Link>
                </Button>
              </div>
            )}

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col gap-4 mt-8">
                   <Link to="/" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                     <img src={logoUrl} alt="QuickTBite Logo" className="h-8" />
                     <div className="flex flex-col">
                        <span className="font-bold text-lg -mb-1">QUICKTBITE</span>
                        <span className="text-xs text-primary font-medium">{slogan}</span>
                     </div>
                   </Link>
                  <Link to="/" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                    <Home className="h-5 w-5" />
                    <span>Inicio</span>
                  </Link>
                  <Link to="/menu" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                    <UtensilsCrossed className="h-5 w-5" />
                    <span>Menú</span>
                  </Link>
                  {currentUser ? (
                    <>
                      <Link to="/profile" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                        <User className="h-5 w-5" />
                        <span>Perfil</span>
                      </Link>
                       <Link to="/track-order" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                        <MapPinIcon className="h-5 w-5" />
                        <span>Seguir Pedido</span>
                      </Link>
                      <Button variant="outline" onClick={handleLogout} className="flex items-center gap-2 p-2 w-full justify-start">
                        <LogOut className="h-5 w-5" />
                        <span>Cerrar Sesión</span>
                      </Button>
                    </>
                  ) : (
                    <>
                      <Link to="/login" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                        <LogIn className="h-5 w-5" />
                        <span>Iniciar Sesión</span>
                      </Link>
                      <Link to="/signup" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                        <UserPlus className="h-5 w-5" />
                        <span>Crear Cuenta</span>
                      </Link>
                    </>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </motion.header>
  );
};

export default Navbar;