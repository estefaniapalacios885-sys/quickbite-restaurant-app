import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/components/ui/use-toast";
import Navbar from "@/components/Navbar";
import Cart from "@/components/Cart";
import HomePage from "@/pages/HomePage";
import MenuPage from "@/pages/MenuPage";
import CheckoutPage from "@/pages/CheckoutPage";
import ProfilePage from "@/pages/ProfilePage";
import TrackOrderPage from "@/pages/TrackOrderPage";
import LoginPage from "@/pages/LoginPage";
import SignUpPage from "@/pages/SignUpPage";
import { foodItems, categories } from "@/data";
import PageLayout from "@/components/layouts/PageLayout";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";

const ProtectedRoute = ({ children }) => {
  const { currentUser } = useAuth();
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

const AppContent = () => {
  const { toast } = useToast();
  const [cartItems, setCartItems] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckout, setIsCheckout] = useState(false);
  const { currentUser } = useAuth();
  
  useEffect(() => {
    const savedCart = localStorage.getItem(`quickbite-cart-${currentUser?.email || 'guest'}`);
    if (savedCart) {
      try {
        setCartItems(JSON.parse(savedCart));
      } catch (error) {
        console.error("Error parsing cart data:", error);
      }
    } else {
      setCartItems([]); 
    }
  }, [currentUser]);
  
  useEffect(() => {
    localStorage.setItem(`quickbite-cart-${currentUser?.email || 'guest'}`, JSON.stringify(cartItems));
  }, [cartItems, currentUser]);
  
  const handleAddToCart = (item) => {
    setCartItems((prevItems) => {
      const existingItem = prevItems.find((cartItem) => cartItem.id === item.id);
      
      if (existingItem) {
        const updatedItems = prevItems.map((cartItem) =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
        
        toast({
          title: "Cantidad actualizada",
          description: `La cantidad de ${item.name} aumentó a ${existingItem.quantity + 1}`,
        });
        
        return updatedItems;
      } else {
        toast({
          title: "Agregado al carrito",
          description: `${item.name} ha sido agregado a tu carrito.`,
        });
        
        return [...prevItems, { ...item, quantity: 1 }];
      }
    });
    setIsCartOpen(true);
  };
  
  const handleUpdateQuantity = (itemId, newQuantity) => {
    if (newQuantity <= 0) {
      handleRemoveItem(itemId);
      return;
    }
    
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };
  
  const handleRemoveItem = (itemId) => {
    setCartItems((prevItems) => {
      const itemToRemove = prevItems.find((item) => item.id === itemId);
      
      if (itemToRemove) {
        toast({
          title: "Artículo eliminado",
          description: `${itemToRemove.name} ha sido eliminado de tu carrito.`,
        });
      }
      
      return prevItems.filter((item) => item.id !== itemId);
    });
  };
  
  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast({
        title: "Carrito Vacío",
        description: "Por favor agrega artículos a tu carrito antes de proceder al pago.",
        variant: "destructive",
      });
      return;
    }
    if (!currentUser) {
      toast({
        title: "Inicio de Sesión Requerido",
        description: "Por favor inicia sesión para continuar con el pago.",
        variant: "destructive",
      });
      setIsCartOpen(false); 
      return;
    }
    setIsCartOpen(false);
    setIsCheckout(true);
  };
  
  const handleCompleteOrder = () => {
    setCartItems([]);
  };
  
  const handleCancelCheckout = () => {
    setIsCheckout(false);
  };
  
  const cartItemsCount = cartItems.reduce((total, item) => total + item.quantity, 0);
  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  const deliveryFee = subtotal > 0 ? 2.99 : 0;
  const total = subtotal + deliveryFee;

  return (
    <>
      <Navbar cartItemsCount={cartItemsCount} onCartClick={() => setIsCartOpen(true)} />
      
      {isCheckout ? (
        <PageLayout>
          <ProtectedRoute>
            <CheckoutPage
              cartItems={cartItems}
              total={total}
              onCompleteOrder={handleCompleteOrder}
              onCancel={handleCancelCheckout}
            />
          </ProtectedRoute>
        </PageLayout>
      ) : (
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route
            path="/menu"
            element={
              <PageLayout>
                <MenuPage
                  foodItems={foodItems}
                  categories={categories}
                  onAddToCart={handleAddToCart}
                />
              </PageLayout>
            }
          />
          <Route path="/profile" element={<PageLayout><ProtectedRoute><ProfilePage /></ProtectedRoute></PageLayout>} />
          <Route path="/track-order" element={<PageLayout><ProtectedRoute><TrackOrderPage /></ProtectedRoute></PageLayout>} />
          <Route path="/login" element={<PageLayout><LoginPage /></PageLayout>} />
          <Route path="/signup" element={<PageLayout><SignUpPage /></PageLayout>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      )}
      
      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />
      
      <Toaster />
    </>
  );
};

const App = () => {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;
